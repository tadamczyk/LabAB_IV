INSERT INTO pacjent(imie, nazwisko, telefon, email, data_ur, miasto_ur) VALUES('Adam', 'Kowalski', '772888999', 'adamk@o2.pl', '01.01.1990', 'Warszawa');
INSERT INTO pacjent(imie, nazwisko, telefon, email, data_ur, miasto_ur) VALUES('Anita', 'Kowalska', '777838990', 'anitak@wp.pl', '23.02.1991', 'Krakow');
INSERT INTO pacjent(imie, nazwisko, telefon, email, data_ur, miasto_ur) VALUES('Anna', 'Miska', '777163456', 'annam@o2.pl', '12.02.1980', 'Gdansk');
INSERT INTO pacjent(imie, nazwisko, telefon, email, data_ur, miasto_ur) VALUES('Janusz', 'Walski', '555662444', 'januszw@wp.pl', '10.10.1991', 'Warszawa');
INSERT INTO pacjent(imie, nazwisko, telefon, email, data_ur, miasto_ur) VALUES('Emilian', 'Parbocki', '700323123', 'emilianp@o2.pl', '02.05.1990', 'Warszawa');
INSERT INTO pacjent(imie, nazwisko, telefon, email, data_ur, miasto_ur) VALUES('Jagoda', 'Niskaska', '666767222', 'jagodan@wp.pl', '23.01.1991', 'Warszawa');

INSERT INTO lekarz(imie, nazwisko, telefon, email, data_ur, miasto_ur) VALUES('Adam', 'Kowal', '777888999', 'adamkowal@o2.pl', '23.03.1980', 'Warszawa');
INSERT INTO lekarz(imie, nazwisko, telefon, email, data_ur, miasto_ur) VALUES('Anna', 'Kowal', '777888990', 'annakowal@wp.pl', '23.04.1982', 'Legionowo');
INSERT INTO lekarz(imie, nazwisko, telefon, email, data_ur, miasto_ur) VALUES('Michal', 'Mis', '777123456', 'michalmis@o2.pl', '20.01.1972', 'Krakow');
INSERT INTO lekarz(imie, nazwisko, telefon, email, data_ur, miasto_ur) VALUES('Jan', 'Walek', '555666444', 'janwalek@wp.pl', '28.03.1964', 'Maks');
INSERT INTO lekarz(imie, nazwisko, telefon, email, data_ur, miasto_ur) VALUES('Ewa', 'Parbocka', '700123123', 'ewaparbocka@o2.pl', '23.09.1972', 'Gdansk');
INSERT INTO lekarz(imie, nazwisko, telefon, email, data_ur, miasto_ur) VALUES('Jagoda', 'Niska', '666777222', 'jagodaniska@wp.pl', '01.12.1956', 'Gdynia');

INSERT INTO konto(id, login, haslo) VALUES(1, 'adam.kowal', 'adam.kowal');
INSERT INTO konto(id, login, haslo) VALUES(2, 'anna.kowal', 'anna.kowal');
INSERT INTO konto(id, login, haslo) VALUES(4, 'jan.walek', 'jan.walek');
INSERT INTO konto(id, login, haslo) VALUES(3, 'michal.mis', 'michal.mis');
INSERT INTO konto(id, login, haslo) VALUES(5, 'ewa.parbocka', 'ewa.parbocka');
INSERT INTO konto(id, login, haslo) VALUES(6, 'jagoda.niska', 'jagoda.niska');

INSERT INTO choroba(nazwa, opis, pochodzenie, nr_medyczny, ilosc_mozliwych_szczepien) VALUES('Grypa', 'Grypa', 'Polska', 12.231, 0);
INSERT INTO choroba(nazwa, opis, pochodzenie, nr_medyczny, ilosc_mozliwych_szczepien) VALUES('Przeziebienie', 'Przeziebienie', 'Polska', 1.123, 0);
INSERT INTO choroba(nazwa, opis, pochodzenie, nr_medyczny, ilosc_mozliwych_szczepien) VALUES('Rak pluc', 'Rak pluc', 'Polska', 666.666, 0);
INSERT INTO choroba(nazwa, opis, pochodzenie, nr_medyczny, ilosc_mozliwych_szczepien) VALUES('Ospa', 'Ospa', 'Polska', 12.12222, 1);
INSERT INTO choroba(nazwa, opis, pochodzenie, nr_medyczny, ilosc_mozliwych_szczepien) VALUES('Nadcisnienie', 'Nadcisnienie', 'Polska', 1.0101, 0);
INSERT INTO choroba(nazwa, opis, pochodzenie, nr_medyczny, ilosc_mozliwych_szczepien) VALUES('Zlamanie', 'Zlamanie', 'Polska' ,123.123, 0);

INSERT INTO wizyta(lekarz_id, pacjent_id, data_wizyty) VALUES(2, 1, '05.01.2016');
INSERT INTO wizyta(lekarz_id, pacjent_id, data_wizyty) VALUES(3, 2, '05.02.2016');
INSERT INTO wizyta(lekarz_id, pacjent_id, data_wizyty) VALUES(4, 3, '05.03.2016');
INSERT INTO wizyta(lekarz_id, pacjent_id, data_wizyty) VALUES(2, 4, '05.04.2016');
INSERT INTO wizyta(lekarz_id, pacjent_id, data_wizyty) VALUES(3, 5, '05.05.2016');
INSERT INTO wizyta(lekarz_id, pacjent_id, data_wizyty) VALUES(4, 6, '05.06.2016');

INSERT INTO historia_chorob(wizyta_id, choroba_id, zalecenia, oplata) VALUES(1, 2, '3 dni zwolnienia', 0);
INSERT INTO historia_chorob(wizyta_id, choroba_id, zalecenia, oplata) VALUES(2, 1, '4 dni zwolnienia', 0);
INSERT INTO historia_chorob(wizyta_id, choroba_id, zalecenia, oplata) VALUES(3, 4, '5 dni zwolnienia', 0);
INSERT INTO historia_chorob(wizyta_id, choroba_id, zalecenia, oplata) VALUES(4, 3, '2 dni zwolnienia', 0);
