package login.controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import login.service.LoginService;

import java.io.IOException;

public class LoginController {
    public static String username = null;

    private LoginService loginService = new LoginService();

    private boolean isConnection = false;
    @FXML
    private Button ZalogujButton;
    @FXML
    private TextField LoginField;
    @FXML
    private PasswordField HasloField;
    @FXML
    private Label PolaczLabel, ZalogujLabel;

    public LoginController() throws Exception {
    }

    @FXML
    public void PolaczAction() {
        try {
            if (this.loginService.isDatabaseConnected()) {
                this.PolaczLabel.setText("   Połączono z bazą danych!   ");
                this.PolaczLabel.setTextFill(Color.web("#42f445"));
                isConnection = true;
            } else {
                this.PolaczLabel.setText("Brak połączenia z bazą danych!");
                this.PolaczLabel.setTextFill(Color.web("#f44141"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void ZalogujAction() {
        try {
            if (!isConnection) {
                this.ZalogujLabel.setText("  Połącz z bazą danych!");
                this.ZalogujLabel.setTextFill(Color.web("#f44141"));
            } else if (this.LoginField.getText().isEmpty()) {
                this.ZalogujLabel.setText("      Wprowadź login!  ");
                this.ZalogujLabel.setTextFill(Color.web("#f44141"));
            } else if (this.HasloField.getText().isEmpty()) {
                this.ZalogujLabel.setText("      Wprowadź hasło!  ");
                this.ZalogujLabel.setTextFill(Color.web("#f44141"));
            } else if (this.loginService.checkLoginData(
                    this.LoginField.getText(),
                    this.HasloField.getText())) {
                username = this.LoginField.getText();
                Stage stage = (Stage) this.ZalogujButton.getScene().getWindow();
                stage.close();
                GoToPrzychodnia();
            } else {
                this.ZalogujLabel.setText("         Błędne dane!  ");
                this.ZalogujLabel.setTextFill(Color.web("#f44141"));
            }
        } catch (Exception localException) {
            localException.printStackTrace();
        }
    }

    private void GoToPrzychodnia() throws IOException {
        Stage stage = new Stage();
        FXMLLoader loader = new FXMLLoader();
        TabPane root = loader.load(getClass().getResource("/przychodnia/PrzychodniaView.fxml").openStream());
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("Przychodnia lekarska");
        stage.getIcons().add(new Image("file:icon.png"));
        stage.setMaximized(true);
        stage.show();
    }

}