INSERT INTO pacjent VALUES ('Adam', 'Kowalski', '772888999', 'adamk@o2.pl', '1990-01-01', 'Warszawa');
INSERT INTO pacjent VALUES ('Anita', 'Kowalska', '777838990', 'anitak@wp.pl', '1991-02-23', 'Krakow');
INSERT INTO pacjent VALUES ('Anna', 'Miska', '777163456', 'annam@o2.pl', '1980-02-12', 'Gdansk');
INSERT INTO pacjent VALUES ('Janusz', 'Walski', '555662444', 'januszw@wp.pl', '1991-10-10', 'Warszawa');
INSERT INTO pacjent VALUES ('Emilian', 'Parbocki', '700323123', 'emilianp@o2.pl', '1994-05-02', 'Warszawa');
INSERT INTO pacjent VALUES ('Jagoda', 'Niskaska', '666767222', 'jagodan@wp.pl', '1995-01-23', 'Warszawa');

INSERT INTO lekarz VALUES ('Adam', 'Kowal', '777888999', 'adamkowal@o2.pl', '1980-03-23', 'Warszawa');
INSERT INTO lekarz VALUES ('Anna', 'Kowal', '777888990', 'annakowal@wp.pl', '1982-02-23', 'Legionowo');
INSERT INTO lekarz VALUES ('Michal', 'Mis', '777123456', 'michalmis@o2.pl', '1974-01-23', 'Krakow');
INSERT INTO lekarz VALUES ('Jan', 'Walek', '555666444', 'janwalek@wp.pl', '1964-03-28', 'Maks');
INSERT INTO lekarz VALUES ('Ewa', 'Parbocka', '700123123', 'ewaparbocka@o2.pl', '1976-09-23', 'Gdansk');
INSERT INTO lekarz VALUES ('Jagoda', 'Niska', '666777222', 'jagodaniska@wp.pl', '1956-09-22', 'Gdynia');

INSERT INTO choroba VALUES ('Grypa', 'Grypa.', 'Polska', 12.231, 0);
INSERT INTO choroba VALUES ('Przeziebienie', 'Przeziebienie.', 'Polska', 1.123, 0);
INSERT INTO choroba VALUES ('Rak pluc', 'Rak pluc.', 'Polska', 666.666, 0);
INSERT INTO choroba VALUES ('Ospa', 'Ospa.', 'Polska', 12.12222, 1);
INSERT INTO choroba VALUES ('Nadcisnienie', 'Nadcisnienie.', 'Polska', 1.0101, 0);
INSERT INTO choroba VALUES ('Zlamanie', 'Zlamanie.', 'Polska' ,123.123, 0);

INSERT INTO wizyta VALUES (2, 1, '2016-01-05', '3 dni zwolnienia.', 0);
INSERT INTO wizyta VALUES (3, 2, '2016-02-05', '4 dni zwolnienia.', 0);
INSERT INTO wizyta VALUES (4, 3, '2016-03-05', '5 dni zwolnienia.', 0);
INSERT INTO wizyta VALUES (2, 4, '2016-04-05', '2 dni zwolnienia.', 0);
INSERT INTO wizyta VALUES (3, 5, '2016-05-05', '7 dni zwolnienia.', 0);
INSERT INTO wizyta VALUES (4, 6, '2016-06-05', 'Brak zwolnienia.', 0);

INSERT INTO historia_chorob VALUES (1, 2);
INSERT INTO historia_chorob VALUES (2, 1);
INSERT INTO historia_chorob VALUES (3, 4);
INSERT INTO historia_chorob VALUES (4, 3);
INSERT INTO historia_chorob VALUES (5, 6);
INSERT INTO historia_chorob VALUES (6, 5);
