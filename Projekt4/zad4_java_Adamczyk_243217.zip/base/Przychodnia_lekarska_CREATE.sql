CREATE TABLE pacjent(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  imie VARCHAR(20) NOT NULL,
  nazwisko VARCHAR(40) NOT NULL,
  telefon VARCHAR(13) NOT NULL,
  email VARCHAR(100) NOT NULL,
  data_ur DATE NOT NULL,
  miasto_ur VARCHAR(40) NOT NULL
);

CREATE TABLE lekarz(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  imie VARCHAR(20) NOT NULL,
  nazwisko VARCHAR(40) NOT NULL,
  telefon VARCHAR(13) NOT NULL,
  email VARCHAR(100) NOT NULL,
  data_ur DATE NOT NULL,
  miasto_ur VARCHAR(40) NOT NULL
);

CREATE TABLE konto(
  id INTEGER NOT NULL REFERENCES lekarz(id),
  login VARCHAR(20) NOT NULL,
  haslo VARCHAR(32) NOT NULL,
  PRIMARY KEY(id)
);

CREATE TABLE choroba(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nazwa VARCHAR(50) NOT NULL,
  opis VARCHAR(200) NOT NULL,
  pochodzenie VARCHAR(40) NOT NULL,
  nr_medyczny DOUBLE NOT NULL,
  ilosc_mozliwych_szczepien INTEGER NOT NULL
);

CREATE TABLE wizyta(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  lekarz_id INTEGER NOT NULL REFERENCES lekarz(id) ON UPDATE CASCADE,
  pacjent_id INTEGER NOT NULL REFERENCES pacjent(id) ON UPDATE CASCADE,
  data_wizyty DATETIME NOT NULL
);

CREATE TABLE historia_chorob(
  wizyta_id INTEGER NOT NULL REFERENCES wizyta(id) ON DELETE CASCADE,
  choroba_id INTEGER NOT NULL REFERENCES choroba(id),
  zalecenia VARCHAR(200) NOT NULL,
  oplata DECIMAL NOT NULL,
  PRIMARY KEY(wizyta_id, choroba_id)
);
