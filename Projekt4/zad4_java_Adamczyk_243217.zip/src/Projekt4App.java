import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

public class Projekt4App extends Application {
    public static void main(String[] args) {
        launch();
    }

    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("/login/LoginView.fxml"));
        stage.setScene(new Scene(root, 480, 480));
        stage.setTitle("Przychodnia lekarska");
        stage.getIcons().add(new Image("file:icon.png"));
        stage.show();
    }

}