/********************************
*        TOMASZ ADAMCZYK        *
*       Nr albumu: 243217       *
*      Informatyka II ROK       *
*     Aplikacje Bazodanowe      *
*     Projekt1.c - ZAD 6.3      *
********************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <libpq-fe.h>
#include <unistd.h>
#define MAX 1000
#define MEDIUM 200
#define MIN 50

enum COUNTER_ARGS{
  ZERO = 0,
  ONE = 1,
  CREATE_TABLE = 2,
  THREE = 3,
  PRINT_HTML = 4
};

void printTuples(PGresult *result){
  int m, n;
  int nRows = PQntuples(result);
  int nFields = PQnfields(result);
  printf("  Number of rows returned   = %d\n", nRows);
  printf("  Number of fields returned = %d\n\n", nFields);
  for (m = 0; m < nRows; m++){
    for (n = 0; n < nFields; n++){
      printf("%16s = %24s;\n", PQfname(result, n), PQgetvalue(result, m, n));
    }
    printf("\n");
  }
}

void doSQL(PGconn *conn, char *command){
  PGresult *result;
  printf("> %s\n", command);
  printf("\n************************************\n");
  result = PQexec(conn, command);
  printf("  Status is     : %s\n", PQresStatus(PQresultStatus(result)));
  printf("  Rows affected : %s\n", PQcmdTuples(result));
  printf("  Result message: %s\n", PQresultErrorMessage(result));
  switch (PQresultStatus(result)){
  case PGRES_TUPLES_OK:
    printTuples(result);
    break;
  }
  printf("************************************\n\n");
  PQclear(result);
}

char *getField(char *line, int num){
  char *tok;
  for (tok = strtok(line, ";"); tok && *tok; tok = strtok(NULL, ";\n")){
    if (!--num){
      return tok;
    }
  }
  return NULL;
}

void checkDBExists(char *dbname, char *result){
  char command[MEDIUM] = { "\0" };
  sprintf(command, "psql -l | cut -d '|' -f1 | grep -w %s > .exist_test", dbname);
  system(command);
  FILE *test = fopen(".exist_test", "r");
  if (test != NULL){
    fseek(test, 0, SEEK_END);
    int length = ftell(test);
    if (length == 0){
      sprintf(result, "createdb %s 2>/dev/null", dbname);
      system(result);
      printf("\nDatabase \"%s\" was created.\n", dbname);
    }
  }
  fclose(test);
  system("rm .exist_test");
}

void createConnInfo(int argc, char *dbname, char *result){
  char createdb[MIN] = { "\0" };
  char username[MIN] = { "\0" };
  char *password;
  printf("\tLog in\n");
  printf("********************************\n");
  if (argc == 2){
    printf("DBname:   ");
    scanf("%s", dbname);
  }
  printf("Username: ");
  scanf("%s", username);
  password  = getpass("Password: ");
  printf("********************************\n\n");
  checkDBExists(dbname, createdb);
  sprintf(result, "host=localhost port=5432 dbname=%s user=%s password=%s", dbname, username, password);
}

bool showLog(PGconn *conn){
  if (PQstatus(conn) == CONNECTION_OK){
    printf("\nConnection made!\n");
    printf("******************************\n");
    printf("PGDBNAME   = %s\n",PQdb(conn));
    printf("PGUSER     = %s\n",PQuser(conn));
    printf("PGPASSWORD = ");
    int passLength = strlen(PQpass(conn));
    while (passLength--){
      printf("*");
    };
    printf("\n");
    printf("PGHOST     = %s\n",PQhost(conn));
    printf("PGPORT     = %s\n",PQport(conn));
    printf("******************************\n\n");
    return true;
  }
  else{
    printf("Connection failed!\n%s\n", PQerrorMessage(conn));
    return false;
  }
}

void createTableName(char *source, char *result){
  strncat(result, source, strlen(source) - 4);
}

void dropTable(char *tableName, char *result){
  sprintf(result, "DROP TABLE %s;", tableName);
}

int countColumns(FILE *file){
  char line[MAX] = { "\0" };
  fseek(file, 0, 0);
  fgets(line, MAX, file);
  char *tmp = strdup(line);
  int i, counter = 1;
  for (i = 0; i < strlen(tmp); i++){
    if (tmp[i] == ';'){
      counter++;
    }
  }
  free(tmp);
  return counter;
}

void createHeaders(FILE *file, char *result){
  char line[MAX] = { "\0" };
  char headers[MAX] = "(";
  fseek(file, 0, 0);
  fgets(line, MAX, file);
  char *tmp = strdup(line);
  int i = 1, counter = countColumns(file);
  while (counter--){
    tmp = strdup(line);
    strcat(headers, getField(tmp, i));
    strcat(headers, ", ");
    i++;
  }
  strncat(result, headers, strlen(headers) - 2);
  strcat(result, ")");
  free(tmp);
}

void createTable(FILE *file, char *tableName, char *result){
  char line[MAX] = { "\0" };
  char columns[MAX] = { "\0" };
  fgets(line, MAX, file);
  char *tmp = strdup(line);
  int i = 1, counter = countColumns(file);
  while (counter--){
    tmp = strdup(line);
    strcat(columns, "\t");
    strcat(columns, getField(tmp, i));
    strcat(columns, " VARCHAR(10),\n");
    i++;
  }
  sprintf(result, "CREATE TABLE %s(\n\tid SERIAL,\n", tableName);
  strncat(result, columns, strlen(columns) - 2);
  strcat(result, "\n);");
  free(tmp);
}

void alterTable(char *tableName, char *columnName, int size, char *result){
  sprintf(result, "ALTER TABLE %s ALTER COLUMN %s TYPE VARCHAR(%d);", tableName, columnName, size);
}

void insert(PGconn *conn, FILE *file, char *tableName){
  char line[MAX] = { "\0" };
  char headers[MEDIUM] = { "\0" };
  createHeaders(file, headers);
  int i = 1, j = 0, counter = countColumns(file);
  fseek(file, 0, 0);
  char head[MEDIUM] = { "\0" };
  fgets(head, MEDIUM, file);
  int maxLength[counter + 1];
  for (i = 1; i <= (counter + 1); i++){
    maxLength[i] = 10;
  }
  while (fgets(line, MAX, file)){
    char insertTable[MAX] = "INSERT INTO ";
    strcat(insertTable, tableName);
    strcat(insertTable, headers);
    strcat(insertTable, " VALUES\n(");
    char *tmp;
    i = 1;
    j = counter;
    while (j--){
      tmp = strdup(line);
      strcat(insertTable, "'");
      strcat(insertTable, getField(tmp, i));
      tmp = strdup(line);
      if (strlen(getField(tmp, i)) > maxLength[i]){
        tmp = strdup(line);
        maxLength[i] = strlen(getField(tmp, i));
        char alterTableCommand[MEDIUM];
        tmp = strdup(head);
        alterTable(tableName, (char*) getField(tmp, i),  maxLength[i], alterTableCommand);
        doSQL(conn, alterTableCommand);
      }
      strcat(insertTable, "'");
      if (j != 0) strcat(insertTable, ",");
      i++;
    }
    strcat(insertTable, ");");
    doSQL(conn, insertTable);
  }
}

void selectTable(char *tableName, char *result){
  sprintf(result, "SELECT * FROM %s;", tableName);
}

void openHTML(FILE *output){
  fprintf(output, "<!DOCTYPE html>\n<html>\n<head>\n<link rel=\"stylesheet\" href=\"mystyle.css\"> \n");
  fprintf(output, "<meta charset=\"utf-8\">\n<title>Tables PostgreSQL</title>\n</head>\n");
  fprintf(output, "<body>\n");
}

void closeHTML(FILE *output){
  fprintf(output, "</body>\n</html>\n");
}

void PQPrint(PGconn *conn, FILE *output, char *tableName, int orderBy){
  PGresult * result;
  char columnNames[MEDIUM][MEDIUM];
  char command[MEDIUM];
  if (orderBy == 1){
    sprintf(command, "SELECT * FROM %s ORDER BY %s;", tableName, "id");
  }
  else{
    sprintf(command, "SELECT * FROM %s ORDER BY %s;", tableName, "nazwisko, imie");
  }
  result = PQexec(conn, command);
  int i, j, columnNumbers = PQnfields(result);
  for (i = 0; i < columnNumbers; i++){
    strcpy(columnNames[i], PQfname(result, i));
  }
  fprintf(output, "<h1>%s</h1>\n<table>\n<tr>\n", tableName);
  for (i = 0; i < columnNumbers; i++){
    fprintf(output, "<th>%s</th>", columnNames[i]);
  }
  fprintf(output, "</tr>\n");
  int rows = PQntuples(result);
  for (i = 0; i < rows; i++){
    if (i % 2 == 0){
      fprintf(output, "<tr class=\"grey2\">\n");
    }
    else{
      fprintf(output, "<tr class=\"grey1\">\n");
    }
    for (j = 0; j < columnNumbers; j++){
      fprintf(output, "<td>%s</td>\n", PQgetvalue(result, i, j));
    }
    fprintf(output, "</tr>\n");
  }
  fprintf(output, "</table>\n");
}

int sortBy(int orderBy){
  printf("Order by: 1-id | 2-name :: ");
  scanf("%d", &orderBy);
  printf("\n");
  return orderBy;
}

int main(int argc, char *argv[]){
  FILE *file = fopen(argv[1], "r");
  FILE *HTML;
  char conninfo[MEDIUM] = { "\0" };
  createConnInfo(argc, argv[1], conninfo);
  PGconn *conn = PQconnectdb(conninfo);
  if (!showLog(conn)){
    return 1;
  };
  char tableName[MIN] = { "\0" };
  char dropTableCommand[MEDIUM] = { "\0" };
  char createTableCommand[MAX] = { "\0" };
  char selectTableCommand[MEDIUM] = { "\0" };
  int orderBy = 1;
  switch(argc){
    case ZERO: ONE: THREE:
      break;
    case CREATE_TABLE:
      createTableName(argv[1], tableName);
      dropTable(tableName, dropTableCommand);
      createTable(file, tableName, createTableCommand);
      selectTable(tableName, selectTableCommand);
      doSQL(conn, dropTableCommand);
      doSQL(conn, createTableCommand);
      insert(conn, file, tableName);
      doSQL(conn, selectTableCommand);
      break;
    case PRINT_HTML:
      orderBy = sortBy(orderBy);
      HTML = fopen(argv[argc-1], "w");
      openHTML(HTML);
      PQPrint(conn, HTML, argv[argc-2], orderBy);
      closeHTML(HTML);
      printf("Website \"%s\" was created.\n\n", argv[argc - 1]);
      break;
    default:
      orderBy = sortBy(orderBy);
      HTML = fopen(argv[argc - 1], "w");
      openHTML(HTML);
      int counter = 2;
      while (counter++ < (argc - 1)){
        PQPrint(conn, HTML, argv[counter - 1], orderBy);
      }
      closeHTML(HTML);
      printf("Website \"%s\" was created.\n\n", argv[argc - 1]);
      break;
  }
  PQfinish(conn);
  return 0;
}
