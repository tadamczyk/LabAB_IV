package dbconnection;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class DbConnection {
    private static String readFile(String filename) throws IOException {
        Scanner scanner = new Scanner(new File(filename));
        String text = scanner.useDelimiter("\\A").next();
        scanner.close();
        return text;
    }

    private static void createDatabase(String dbname) throws SQLException {
        String url = "jdbc:sqlite:" + dbname;
        Connection conn = DriverManager.getConnection(url);
    }

    private static void executeCommandFromFile(String dbname, String input) throws SQLException, IOException {
        Connection conn = null;
        try {
            String url = "jdbc:sqlite:" + dbname;
            conn = DriverManager.getConnection(url);
            Statement stmt = conn.createStatement();
            String sql = readFile(input);
            stmt.executeUpdate(sql);
            stmt.close();
        } finally {
            if (conn != null) {
                conn.close();
            }
        }
    }

    public static Connection connect(String dbname, String createFile, String insertFile) throws Exception {
        File file = new File(dbname);
        if (!file.exists()) {
            createDatabase(dbname);
            executeCommandFromFile(dbname, createFile);
            executeCommandFromFile(dbname, insertFile);
        }
        return DriverManager.getConnection("jdbc:sqlite:" + dbname);
    }

}