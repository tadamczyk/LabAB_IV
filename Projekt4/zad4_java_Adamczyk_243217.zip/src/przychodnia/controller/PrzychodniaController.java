package przychodnia.controller;

import dbconnection.DbConnection;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import login.controller.LoginController;
import przychodnia.model.*;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@SuppressWarnings("ALL")
public class PrzychodniaController implements Initializable {
    public static final Pattern VALID_EMAIL_ADDRESS_REGEX =
            Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);
    public DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy");
    private DbConnection db;
    @FXML
    private TextField LekarzIdField, LekarzImieField, LekarzNazwiskoField, LekarzTelefonField, LekarzEmailField, LekarzMiasto_urField;
    @FXML
    private DatePicker LekarzData_urDatePicker;
    @FXML
    private TableView<Lekarz> LekarzTableView;
    @FXML
    private TableColumn<Lekarz, String> LekarzTableImie, LekarzTableNazwisko, LekarzTableTelefon, LekarzTableEmail, LekarzTableData_ur, LekarzTableMiasto_ur;
    @FXML
    private Button LekarzDodajButton, LekarzEdytujButton, LekarzUsunButton, LekarzWyczyscButton, LekarzLadujButton;
    @FXML
    private ObservableList<Lekarz> LekarzList;
    @FXML
    private Tab LekarzTab;
    @FXML
    private TextField PacjentIdField, PacjentImieField, PacjentNazwiskoField, PacjentTelefonField, PacjentEmailField, PacjentMiasto_urField;
    @FXML
    private DatePicker PacjentData_urDatePicker;
    @FXML
    private TableView<Pacjent> PacjentTableView;
    @FXML
    private TableColumn<Pacjent, String> PacjentTableImie, PacjentTableNazwisko, PacjentTableTelefon, PacjentTableEmail, PacjentTableData_ur, PacjentTableMiasto_ur;
    @FXML
    private Button PacjentDodajButton, PacjentEdytujButton, PacjentUsunButton, PacjentWyczyscButton, PacjentLadujButton;
    @FXML
    private ObservableList<Pacjent> PacjentList;
    @FXML
    private Tab PacjentTab;
    @FXML
    private TextField ChorobaIdField, ChorobaNazwaField, ChorobaOpisField, ChorobaPochodzenieField, ChorobaNr_medycznyField, ChorobaIlosc_mozliwych_szczepienField;
    @FXML
    private TableView<Choroba> ChorobaTableView;
    @FXML
    private TableColumn<Choroba, String> ChorobaTableNazwa, ChorobaTableOpis, ChorobaTablePochodzenie, ChorobaTableNr_medyczny, ChorobaTableIlosc_mozliwych_szczepien;
    @FXML
    private Button ChorobaDodajButton, ChorobaEdytujButton, ChorobaUsunButton, ChorobaWyczyscButton, ChorobaLadujButton;
    @FXML
    private ObservableList<Choroba> ChorobaList;
    @FXML
    private Tab ChorobaTab;
    @FXML
    private TextField WizytaIdField;
    @FXML
    private ComboBox WizytaLekarz_idComboBox, WizytaPacjent_idComboBox;
    @FXML
    private ObservableList lekarzCombo = FXCollections.observableArrayList();
    @FXML
    private ObservableList pacjentCombo = FXCollections.observableArrayList();
    @FXML
    private DatePicker WizytaData_wizytyDatePicker;
    @FXML
    private TableView<Wizyta> WizytaTableView;
    @FXML
    private TableColumn<Wizyta, String> WizytaTableLekarz_id, WizytaTablePacjent_id, WizytaTableData_wizyty;
    @FXML
    private Button WizytaDodajButton, WizytaEdytujButton, WizytaUsunButton, WizytaWyczyscButton, WizytaLadujButton;
    @FXML
    private ObservableList<Wizyta> WizytaList;
    @FXML
    private Tab WizytaTab;
    @FXML
    private ComboBox HistoriaWizyta_idComboBox, HistoriaChoroba_idComboBox;
    @FXML
    private ObservableList wizytaCombo = FXCollections.observableArrayList();
    @FXML
    private ObservableList chorobaCombo = FXCollections.observableArrayList();
    @FXML
    private TextArea HistoriaZaleceniaField;
    @FXML
    private TextField HistoriaOplataField;
    @FXML
    private TableView<Historia> HistoriaTableView;
    @FXML
    private TableColumn<Historia, String> HistoriaTableWizyta_id, HistoriaTableChoroba_id, HistoriaTableZalecenia, HistoriaTableOplata;
    @FXML
    private Button HistoriaDodajButton, HistoriaEdytujButton, HistoriaUsunButton, HistoriaWyczyscButton, HistoriaLadujButton;
    @FXML
    private ObservableList<Historia> HistoriaList;
    @FXML
    private Tab HistoriaTab;
    @FXML
    private Label Login1Label, Login2Label, Login3Label, Login4Label, Login5Label;
    @FXML
    private Button WylogujSie1Button;

    public static boolean isEmail(String emailStr) {
        Matcher matcher = VALID_EMAIL_ADDRESS_REGEX.matcher(emailStr);
        return matcher.find();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        this.db = new DbConnection();
        Login1Label.setText(LoginController.username);
        Login2Label.setText(LoginController.username);
        Login3Label.setText(LoginController.username);
        Login4Label.setText(LoginController.username);
        Login5Label.setText(LoginController.username);
        try {
            selectedTab();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void selectedTab() throws Exception {
        if (LekarzTab.isSelected()) {
            ObservableList<Lekarz> selectedRow = LekarzTableView.getSelectionModel().getSelectedItems();
            selectedRow.addListener(new ListChangeListener() {
                @Override
                public void onChanged(Change c) throws NullPointerException, DateTimeParseException {
                    Lekarz selectedR = LekarzTableView.getSelectionModel().getSelectedItem();
                    LekarzIdField.setText(selectedR.getId());
                    LekarzImieField.setText(selectedR.getImie());
                    LekarzNazwiskoField.setText(selectedR.getNazwisko());
                    LekarzTelefonField.setText(selectedR.getTelefon());
                    LekarzEmailField.setText(selectedR.getEmail());
                    LekarzMiasto_urField.setText(selectedR.getMiasto_ur());
                    LekarzData_urDatePicker.setValue(LocalDate.parse(selectedR.getData_ur(), formatter));
                }
            });
        } else if (PacjentTab.isSelected()) {
            ObservableList<Pacjent> selectedRow = PacjentTableView.getSelectionModel().getSelectedItems();
            selectedRow.addListener(new ListChangeListener() {
                @Override
                public void onChanged(Change c) throws NullPointerException, DateTimeParseException {
                    Pacjent selectedR = PacjentTableView.getSelectionModel().getSelectedItem();
                    PacjentIdField.setText(selectedR.getId());
                    PacjentImieField.setText(selectedR.getImie());
                    PacjentNazwiskoField.setText(selectedR.getNazwisko());
                    PacjentTelefonField.setText(selectedR.getTelefon());
                    PacjentEmailField.setText(selectedR.getEmail());
                    PacjentMiasto_urField.setText(selectedR.getMiasto_ur());
                    PacjentData_urDatePicker.setValue(LocalDate.parse(selectedR.getData_ur(), formatter));
                }
            });
        } else if (ChorobaTab.isSelected()) {
            ObservableList<Choroba> selectedRow = ChorobaTableView.getSelectionModel().getSelectedItems();
            selectedRow.addListener(new ListChangeListener() {
                @Override
                public void onChanged(Change c) throws NullPointerException {
                    Choroba selectedR = ChorobaTableView.getSelectionModel().getSelectedItem();
                    ChorobaIdField.setText(selectedR.getId());
                    ChorobaNazwaField.setText(selectedR.getNazwa());
                    ChorobaOpisField.setText(selectedR.getOpis());
                    ChorobaPochodzenieField.setText(selectedR.getPochodzenie());
                    ChorobaNr_medycznyField.setText(selectedR.getNr_medyczny());
                    ChorobaIlosc_mozliwych_szczepienField.setText(selectedR.getIlosc_mozliwych_szczepien());
                }
            });
        } else if (WizytaTab.isSelected()) {
            loadWizytaCombo();
            ObservableList<Wizyta> selectedRow = WizytaTableView.getSelectionModel().getSelectedItems();
            selectedRow.addListener(new ListChangeListener() {
                @Override
                public void onChanged(Change c) throws NullPointerException {
                    Wizyta selectedR = WizytaTableView.getSelectionModel().getSelectedItem();
                    WizytaIdField.setText(selectedR.getId());
                    String lekarz = selectedR.getLekarz_id();
                    String pacjent = selectedR.getPacjent_id();
                    WizytaLekarz_idComboBox.getSelectionModel().select(lekarz);
                    WizytaPacjent_idComboBox.getSelectionModel().select(pacjent);
                    WizytaData_wizytyDatePicker.setValue(LocalDate.parse(selectedR.getData_wizyty(), formatter));
                }
            });
        } else if (HistoriaTab.isSelected()) {
            loadHistoriaCombo();
            ObservableList<Historia> selectedRow = HistoriaTableView.getSelectionModel().getSelectedItems();
            selectedRow.addListener(new ListChangeListener() {
                @Override
                public void onChanged(Change c) throws NullPointerException {
                    Historia selectedR = HistoriaTableView.getSelectionModel().getSelectedItem();
                    String wizyta = selectedR.getWizyta_id();
                    String choroba = selectedR.getChoroba_id();
                    HistoriaWizyta_idComboBox.getSelectionModel().select(wizyta);
                    HistoriaChoroba_idComboBox.getSelectionModel().select(choroba);
                    HistoriaZaleceniaField.setText(selectedR.getZalecenia());
                    HistoriaOplataField.setText(selectedR.getOplata());
                }
            });
        }
    }

    @FXML
    public void loadWizytaCombo() throws SQLException, NullPointerException, Exception {
        String queryLekarz = "SELECT (nazwisko || ' ' || imie) AS lek FROM lekarz;";
        String queryPacjent = "SELECT (nazwisko || ' ' || imie) AS pac FROM pacjent;";
        WizytaLekarz_idComboBox.setItems(null);
        WizytaPacjent_idComboBox.setItems(null);
        lekarzCombo.clear();
        pacjentCombo.clear();
        Connection conn = DbConnection.connect("Projekt4.sqlite",
                "base/Przychodnia_lekarska_CREATE.sql", "base/Przychodnia_lekarska_INSERT.sql");
        ResultSet rs = conn.prepareStatement(queryLekarz).executeQuery();
        while (rs.next()) {
            lekarzCombo.add(rs.getString(1));
        }
        WizytaLekarz_idComboBox.setItems(lekarzCombo);
        rs = conn.prepareStatement(queryPacjent).executeQuery();
        while (rs.next()) {
            pacjentCombo.add(rs.getString(1));
        }
        WizytaPacjent_idComboBox.setItems(pacjentCombo);
        conn.close();
    }

    @FXML
    public void loadHistoriaCombo() throws SQLException, NullPointerException, Exception {
        String queryWizyta = "SELECT (p.nazwisko || ' ' || p.imie || ' - ' || w.data_wizyty) AS wiz FROM wizyta AS w JOIN pacjent AS p ON w.pacjent_id = p.id;";
        String queryChoroba = "SELECT nazwa FROM choroba;";
        HistoriaWizyta_idComboBox.setItems(null);
        HistoriaChoroba_idComboBox.setItems(null);
        wizytaCombo.clear();
        chorobaCombo.clear();
        Connection conn = DbConnection.connect("Projekt4.sqlite",
                "base/Przychodnia_lekarska_CREATE.sql", "base/Przychodnia_lekarska_INSERT.sql");
        ResultSet rs = conn.prepareStatement(queryWizyta).executeQuery();
        while (rs.next()) {
            wizytaCombo.add(rs.getString(1));
        }
        HistoriaWizyta_idComboBox.setItems(wizytaCombo);
        rs = conn.prepareStatement(queryChoroba).executeQuery();
        while (rs.next()) {
            chorobaCombo.add(rs.getString(1));
        }
        HistoriaChoroba_idComboBox.setItems(chorobaCombo);
        conn.close();
    }

    @FXML
    public void loadLekarzData(ActionEvent actionEvent) throws SQLException, Exception {
        String query = "SELECT * FROM lekarz;";
        Connection conn = DbConnection.connect("Projekt4.sqlite",
                "base/Przychodnia_lekarska_CREATE.sql", "base/Przychodnia_lekarska_INSERT.sql");
        this.LekarzList = FXCollections.observableArrayList();
        ResultSet rs = conn.createStatement().executeQuery(query);
        while (rs.next()) {
            this.LekarzList.add(new Lekarz(
                    rs.getString(1),
                    rs.getString(2),
                    rs.getString(3),
                    rs.getString(4),
                    rs.getString(5),
                    rs.getString(6),
                    rs.getString(7)
            ));
        }
        this.LekarzTableImie.setCellValueFactory(new PropertyValueFactory<Lekarz, String>("imie"));
        this.LekarzTableNazwisko.setCellValueFactory(new PropertyValueFactory<Lekarz, String>("nazwisko"));
        this.LekarzTableTelefon.setCellValueFactory(new PropertyValueFactory<Lekarz, String>("telefon"));
        this.LekarzTableEmail.setCellValueFactory(new PropertyValueFactory<Lekarz, String>("email"));
        this.LekarzTableData_ur.setCellValueFactory(new PropertyValueFactory<Lekarz, String>("data_ur"));
        this.LekarzTableMiasto_ur.setCellValueFactory(new PropertyValueFactory<Lekarz, String>("miasto_ur"));
        this.LekarzTableView.setItems(this.LekarzList);
    }

    @FXML
    public void loadPacjentData(ActionEvent actionEvent) throws SQLException, Exception {
        String query = "SELECT * FROM pacjent;";
        Connection conn = DbConnection.connect("Projekt4.sqlite",
                "base/Przychodnia_lekarska_CREATE.sql", "base/Przychodnia_lekarska_INSERT.sql");
        this.PacjentList = FXCollections.observableArrayList();
        ResultSet rs = conn.createStatement().executeQuery(query);
        while (rs.next()) {
            this.PacjentList.add(new Pacjent(
                    rs.getString(1),
                    rs.getString(2),
                    rs.getString(3),
                    rs.getString(4),
                    rs.getString(5),
                    rs.getString(6),
                    rs.getString(7)
            ));
        }
        this.PacjentTableImie.setCellValueFactory(new PropertyValueFactory<Pacjent, String>("imie"));
        this.PacjentTableNazwisko.setCellValueFactory(new PropertyValueFactory<Pacjent, String>("nazwisko"));
        this.PacjentTableTelefon.setCellValueFactory(new PropertyValueFactory<Pacjent, String>("telefon"));
        this.PacjentTableEmail.setCellValueFactory(new PropertyValueFactory<Pacjent, String>("email"));
        this.PacjentTableData_ur.setCellValueFactory(new PropertyValueFactory<Pacjent, String>("data_ur"));
        this.PacjentTableMiasto_ur.setCellValueFactory(new PropertyValueFactory<Pacjent, String>("miasto_ur"));
        this.PacjentTableView.setItems(this.PacjentList);
    }

    @FXML
    public void loadChorobaData(ActionEvent actionEvent) throws SQLException, Exception {
        String query = "SELECT * FROM choroba;";
        Connection conn = DbConnection.connect("Projekt4.sqlite",
                "base/Przychodnia_lekarska_CREATE.sql", "base/Przychodnia_lekarska_INSERT.sql");
        this.ChorobaList = FXCollections.observableArrayList();
        ResultSet rs = conn.createStatement().executeQuery(query);
        while (rs.next()) {
            this.ChorobaList.add(new Choroba(
                    rs.getString(1),
                    rs.getString(2),
                    rs.getString(3),
                    rs.getString(4),
                    rs.getString(5),
                    rs.getString(6)
            ));
        }
        this.ChorobaTableNazwa.setCellValueFactory(new PropertyValueFactory<Choroba, String>("nazwa"));
        this.ChorobaTableOpis.setCellValueFactory(new PropertyValueFactory<Choroba, String>("opis"));
        this.ChorobaTablePochodzenie.setCellValueFactory(new PropertyValueFactory<Choroba, String>("pochodzenie"));
        this.ChorobaTableNr_medyczny.setCellValueFactory(new PropertyValueFactory<Choroba, String>("nr_medyczny"));
        this.ChorobaTableIlosc_mozliwych_szczepien.setCellValueFactory(new PropertyValueFactory<Choroba, String>("ilosc_mozliwych_szczepien"));
        this.ChorobaTableView.setItems(this.ChorobaList);
    }

    @FXML
    public void loadWizytaData(ActionEvent actionEvent) throws SQLException, Exception {
        String query = "SELECT w.id, (l.nazwisko || ' ' || l.imie) AS lek, (p.nazwisko || ' ' || p.imie) AS pac, w.lekarz_id, w.pacjent_id, w.data_wizyty FROM wizyta AS w JOIN lekarz AS l ON w.lekarz_id = l.id JOIN pacjent AS p ON w.pacjent_id = p.id;";
        Connection conn = DbConnection.connect("Projekt4.sqlite",
                "base/Przychodnia_lekarska_CREATE.sql", "base/Przychodnia_lekarska_INSERT.sql");
        this.WizytaList = FXCollections.observableArrayList();
        ResultSet rs = conn.createStatement().executeQuery(query);
        while (rs.next()) {
            this.WizytaList.add(new Wizyta(
                    rs.getString(1),
                    rs.getString(2),
                    rs.getString(3),
                    rs.getString(6)
            ));
        }
        this.WizytaTableLekarz_id.setCellValueFactory(new PropertyValueFactory<Wizyta, String>("lekarz_id"));
        this.WizytaTablePacjent_id.setCellValueFactory(new PropertyValueFactory<Wizyta, String>("pacjent_id"));
        this.WizytaTableData_wizyty.setCellValueFactory(new PropertyValueFactory<Wizyta, String>("data_wizyty"));
        this.WizytaTableView.setItems(this.WizytaList);
    }

    @FXML
    public void loadHistoriaData(ActionEvent actionEvent) throws SQLException, Exception {
        String query = "SELECT (p.nazwisko || ' ' || p.imie || ' - ' || w.data_wizyty) AS wiz, h.wizyta_id,  c.nazwa, h.zalecenia, h.oplata FROM historia_chorob AS h JOIN choroba AS c ON h.choroba_id = c.id JOIN wizyta AS w ON h.wizyta_id = w.id JOIN pacjent AS p ON w.pacjent_id = p.id;";
        Connection conn = DbConnection.connect("Projekt4.sqlite",
                "base/Przychodnia_lekarska_CREATE.sql", "base/Przychodnia_lekarska_INSERT.sql");
        this.HistoriaList = FXCollections.observableArrayList();
        ResultSet rs = conn.createStatement().executeQuery(query);
        while (rs.next()) {
            this.HistoriaList.add(new Historia(
                    rs.getString(1),
                    rs.getString(3),
                    rs.getString(4),
                    rs.getString(5)
            ));
        }
        this.HistoriaTableWizyta_id.setCellValueFactory(new PropertyValueFactory<Historia, String>("wizyta_id"));
        this.HistoriaTableChoroba_id.setCellValueFactory(new PropertyValueFactory<Historia, String>("choroba_id"));
        this.HistoriaTableZalecenia.setCellValueFactory(new PropertyValueFactory<Historia, String>("zalecenia"));
        this.HistoriaTableOplata.setCellValueFactory(new PropertyValueFactory<Historia, String>("oplata"));
        this.HistoriaTableView.setItems(this.HistoriaList);
    }

    @FXML
    public void addLekarz(ActionEvent actionEvent) throws Exception {
        String insertQuery = "INSERT INTO lekarz(imie, nazwisko, telefon, email, data_ur, miasto_ur) VALUES (?,?,?,?,?,?);";
        String checkUniqueTelefon = "SELECT id FROM lekarz WHERE telefon = ?;";
        Connection conn = DbConnection.connect("Projekt4.sqlite",
                "base/Przychodnia_lekarska_CREATE.sql", "base/Przychodnia_lekarska_INSERT.sql");
        PreparedStatement stm = conn.prepareStatement(insertQuery);
        if (!isName(this.LekarzImieField.getText()) || !isValidLen(this.LekarzImieField.getText(), 20)) {
            setAlertError("Błędne dane!", "Imię nie jest poprawne (zawiera niedozwolone znaki bądż ma złą długość)!");
            LekarzImieField.setText(null);
            return;
        } else if (!isName(this.LekarzNazwiskoField.getText()) || !isValidLen(this.LekarzNazwiskoField.getText(), 40)) {
            setAlertError("Błędne dane!", "Nazwisko nie jest poprawne (zawiera niedozwolone znaki bądż ma złą długość)!");
            LekarzNazwiskoField.setText(null);
            return;
        } else if (!isUnique(this.LekarzTelefonField.getText(), checkUniqueTelefon)) {
            setAlertError("Błędne dane!", "Istnieje taki numer telefonu!");
            LekarzTelefonField.setText(null);
            return;
        } else if (!isValidLen(this.LekarzTelefonField.getText(), 13) || !isPhoneNumber(this.LekarzTelefonField.getText())) {
            setAlertError("Błędne dane!", "Numer telefonu nie jest poprawny(ma złą długość lub format)!");
            LekarzTelefonField.setText(null);
            return;
        } else if (!isValidLen(this.LekarzEmailField.getText(), 100) || !isEmail(this.LekarzEmailField.getText())) {
            setAlertError("Błędne dane!", "Email nie jest poprawny(ma złą długość lub format)!");
            LekarzEmailField.setText(null);
            return;
        } else if (this.LekarzData_urDatePicker.getValue() == null || this.LekarzData_urDatePicker.getValue().isAfter(LocalDate.now())) {
            setAlertError("Niepoprawny wybór!", "Data urodzenia jest pusta lub wybiega w przyszłość!");
            return;
        } else if (!isName(this.LekarzMiasto_urField.getText()) || !isValidLen(this.LekarzMiasto_urField.getText(), 40)) {
            setAlertError("Błędne dane!", "Miasto urodzenia nie jest poprawne (zawiera niedozwolone znaki bądż ma złą długość)!");
            LekarzMiasto_urField.setText(null);
            return;
        } else {
            stm.setString(1, String.valueOf(PrzychodniaController.this.LekarzImieField.getText()));
            stm.setString(2, String.valueOf(PrzychodniaController.this.LekarzNazwiskoField.getText()));
            stm.setString(3, String.valueOf(PrzychodniaController.this.LekarzTelefonField.getText()));
            stm.setString(4, String.valueOf(PrzychodniaController.this.LekarzEmailField.getText()));
            stm.setString(5, String.valueOf(PrzychodniaController.this.LekarzData_urDatePicker.getEditor().getText()));
            stm.setString(6, String.valueOf(PrzychodniaController.this.LekarzMiasto_urField.getText()));
            stm.execute();
            LekarzLadujButton.fire();
        }
        conn.close();
    }

    @FXML
    public void editLekarz(ActionEvent actionEvent) throws Exception {
        String updateQuery = "UPDATE lekarz SET imie = ?, nazwisko = ?, telefon = ?, email = ?, data_ur = ?, miasto_ur = ? "
                + " WHERE id = ?;";
        String checkUniqueTelefon = "SELECT id FROM lekarz WHERE telefon = ?;";
        Lekarz getSelectedRow = LekarzTableView.getSelectionModel().getSelectedItem();
        String id = this.LekarzIdField.getText();
        Connection conn = DbConnection.connect("Projekt4.sqlite",
                "base/Przychodnia_lekarska_CREATE.sql", "base/Przychodnia_lekarska_INSERT.sql");
        PreparedStatement stm = conn.prepareStatement(updateQuery);
        if (!isName(this.LekarzImieField.getText()) || !isValidLen(this.LekarzImieField.getText(), 20)) {
            setAlertError("Błędne dane!", "Imię nie jest poprawne (zawiera niedozwolone znaki bądż ma złą długość)!");
            LekarzImieField.setText(null);
            return;
        } else if (!isName(this.LekarzNazwiskoField.getText()) || !isValidLen(this.LekarzNazwiskoField.getText(), 40)) {
            setAlertError("Błędne dane!", "Nazwisko nie jest poprawne (zawiera niedozwolone znaki bądż ma złą długość)!");
            LekarzNazwiskoField.setText(null);
            return;
        } else if (!isValidLen(this.LekarzTelefonField.getText(), 13) || !isPhoneNumber(this.LekarzTelefonField.getText())) {
            setAlertError("Błędne dane!", "Numer telefonu nie jest poprawny(ma złą długość lub format)!");
            LekarzTelefonField.setText(null);
            return;
        } else if (!isValidLen(this.LekarzEmailField.getText(), 100) || !isEmail(this.LekarzEmailField.getText())) {
            setAlertError("Błędne dane!", "Email nie jest poprawny(ma złą długość lub format)!");
            LekarzEmailField.setText(null);
            return;
        } else if (this.LekarzData_urDatePicker.getValue() == null || this.LekarzData_urDatePicker.getValue().isAfter(LocalDate.now())) {
            setAlertError("Niepoprawny wybór!", "Data urodzenia jest pusta lub wybiega w przyszłość!");
            return;
        } else if (!isName(this.LekarzMiasto_urField.getText()) || !isValidLen(this.LekarzMiasto_urField.getText(), 40)) {
            setAlertError("Błędne dane!", "Miasto urodzenia nie jest poprawne (zawiera niedozwolone znaki bądż ma złą długość)!");
            LekarzMiasto_urField.setText(null);
            return;
        } else {
            stm.setString(1, String.valueOf(PrzychodniaController.this.LekarzImieField.getText()));
            stm.setString(2, String.valueOf(PrzychodniaController.this.LekarzNazwiskoField.getText()));
            stm.setString(3, String.valueOf(PrzychodniaController.this.LekarzTelefonField.getText()));
            stm.setString(4, String.valueOf(PrzychodniaController.this.LekarzEmailField.getText()));
            stm.setString(5, String.valueOf(PrzychodniaController.this.LekarzData_urDatePicker.getEditor().getText()));
            stm.setString(6, String.valueOf(PrzychodniaController.this.LekarzMiasto_urField.getText()));
            stm.setInt(7, Integer.parseInt(id));
            stm.execute();
            LekarzLadujButton.fire();
            stm.close();
        }
        conn.close();
    }

    @FXML
    public void deleteLekarz(ActionEvent actionEvent) throws SQLException, NullPointerException, Exception {
        String deleteQuery = "DELETE FROM lekarz WHERE id = ";
        Lekarz getSelectedRow = LekarzTableView.getSelectionModel().getSelectedItem();
        Connection conn = DbConnection.connect("Projekt4.sqlite",
                "base/Przychodnia_lekarska_CREATE.sql", "base/Przychodnia_lekarska_INSERT.sql");
        if (!getSelectedRow.toString().equals("")) {
            String id = this.LekarzIdField.getText();
            deleteQuery += id + "; ";
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Potwierdzenie usunięcia");
            alert.setHeaderText("Chcesz usunąć lekarza?");
            alert.setContentText("" + getSelectedRow.getNazwisko() + " " + getSelectedRow.getImie());
            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK) {
                PreparedStatement stm = conn.prepareStatement(deleteQuery);
                stm.execute();
                LekarzLadujButton.fire();
                stm.close();
            }
        }
        conn.close();
    }

    @FXML
    private void clearLekarz(ActionEvent event) {
        this.LekarzIdField.setText(null);
        this.LekarzImieField.setText(null);
        this.LekarzNazwiskoField.setText(null);
        this.LekarzTelefonField.setText(null);
        this.LekarzEmailField.setText(null);
        this.LekarzMiasto_urField.setText(null);
        this.LekarzData_urDatePicker.setValue(null);
    }

    @FXML
    public void addPacjent(ActionEvent actionEvent) throws Exception {
        String insertQuery = "INSERT INTO pacjent(imie, nazwisko, telefon, email, data_ur, miasto_ur) VALUES (?,?,?,?,?,?);";
        String checkUniqueTelefon = "SELECT id FROM pacjent WHERE telefon = ?;";
        Connection conn = DbConnection.connect("Projekt4.sqlite",
                "base/Przychodnia_lekarska_CREATE.sql", "base/Przychodnia_lekarska_INSERT.sql");
        PreparedStatement stm = conn.prepareStatement(insertQuery);
        if (!isName(this.PacjentImieField.getText()) || !isValidLen(this.PacjentImieField.getText(), 20)) {
            setAlertError("Błędne dane!", "Imię nie jest poprawne (zawiera niedozwolone znaki bądż ma złą długość)!");
            PacjentImieField.setText(null);
            return;
        } else if (!isName(this.PacjentNazwiskoField.getText()) || !isValidLen(this.PacjentNazwiskoField.getText(), 40)) {
            setAlertError("Błędne dane!", "Nazwisko nie jest poprawne (zawiera niedozwolone znaki bądż ma złą długość)!");
            PacjentNazwiskoField.setText(null);
            return;
        } else if (!isUnique(this.PacjentTelefonField.getText(), checkUniqueTelefon)) {
            setAlertError("Błędne dane!", "Istnieje taki numer telefonu!");
            PacjentTelefonField.setText(null);
            return;
        } else if (!isValidLen(this.PacjentTelefonField.getText(), 13) || !isPhoneNumber(this.PacjentTelefonField.getText())) {
            setAlertError("Błędne dane!", "Numer telefonu nie jest poprawny(ma złą długość lub format)!");
            PacjentTelefonField.setText(null);
            return;
        } else if (!isValidLen(this.PacjentEmailField.getText(), 100) || !isEmail(this.PacjentEmailField.getText())) {
            setAlertError("Błędne dane!", "Email nie jest poprawny(ma złą długość lub format)!");
            PacjentEmailField.setText(null);
            return;
        } else if (this.PacjentData_urDatePicker.getValue() == null || this.PacjentData_urDatePicker.getValue().isAfter(LocalDate.now())) {
            setAlertError("Niepoprawny wybór!", "Data urodzenia jest pusta lub wybiega w przyszłość!");
            return;
        } else if (!isName(this.PacjentMiasto_urField.getText()) || !isValidLen(this.PacjentMiasto_urField.getText(), 40)) {
            setAlertError("Błędne dane!", "Miasto urodzenia nie jest poprawne (zawiera niedozwolone znaki bądż ma złą długość)!");
            PacjentMiasto_urField.setText(null);
            return;
        } else {
            stm.setString(1, String.valueOf(PrzychodniaController.this.PacjentImieField.getText()));
            stm.setString(2, String.valueOf(PrzychodniaController.this.PacjentNazwiskoField.getText()));
            stm.setString(3, String.valueOf(PrzychodniaController.this.PacjentTelefonField.getText()));
            stm.setString(4, String.valueOf(PrzychodniaController.this.PacjentEmailField.getText()));
            stm.setString(5, String.valueOf(PrzychodniaController.this.PacjentData_urDatePicker.getEditor().getText()));
            stm.setString(6, String.valueOf(PrzychodniaController.this.PacjentMiasto_urField.getText()));
            stm.execute();
            PacjentLadujButton.fire();
        }
        conn.close();
    }

    @FXML
    public void editPacjent(ActionEvent actionEvent) throws Exception {
        String updateQuery = "UPDATE pacjent SET imie = ?, nazwisko = ?, telefon = ?, email = ?, data_ur = ?, miasto_ur = ? "
                + " WHERE id = ?;";
        String checkUniqueTelefon = "SELECT id FROM pacjent WHERE telefon = ?;";
        Pacjent getSelectedRow = PacjentTableView.getSelectionModel().getSelectedItem();
        String id = this.PacjentIdField.getText();
        Connection conn = DbConnection.connect("Projekt4.sqlite",
                "base/Przychodnia_lekarska_CREATE.sql", "base/Przychodnia_lekarska_INSERT.sql");
        PreparedStatement stm = conn.prepareStatement(updateQuery);
        if (!isName(this.PacjentImieField.getText()) || !isValidLen(this.PacjentImieField.getText(), 20)) {
            setAlertError("Błędne dane!", "Imię nie jest poprawne (zawiera niedozwolone znaki bądż ma złą długość)!");
            PacjentImieField.setText(null);
            return;
        } else if (!isName(this.PacjentNazwiskoField.getText()) || !isValidLen(this.PacjentNazwiskoField.getText(), 40)) {
            setAlertError("Błędne dane!", "Nazwisko nie jest poprawne (zawiera niedozwolone znaki bądż ma złą długość)!");
            PacjentNazwiskoField.setText(null);
            return;
        } else if (!isValidLen(this.PacjentTelefonField.getText(), 13) || !isPhoneNumber(this.PacjentTelefonField.getText())) {
            setAlertError("Błędne dane!", "Numer telefonu nie jest poprawny(ma złą długość lub format)!");
            PacjentTelefonField.setText(null);
            return;
        } else if (!isValidLen(this.PacjentEmailField.getText(), 100) || !isEmail(this.PacjentEmailField.getText())) {
            setAlertError("Błędne dane!", "Email nie jest poprawny(ma złą długość lub format)!");
            PacjentEmailField.setText(null);
            return;
        } else if (this.PacjentData_urDatePicker.getValue() == null || this.PacjentData_urDatePicker.getValue().isAfter(LocalDate.now())) {
            setAlertError("Niepoprawny wybór!", "Data urodzenia jest pusta lub wybiega w przyszłość!");
            return;
        } else if (!isName(this.PacjentMiasto_urField.getText()) || !isValidLen(this.PacjentMiasto_urField.getText(), 40)) {
            setAlertError("Błędne dane!", "Miasto urodzenia nie jest poprawne (zawiera niedozwolone znaki bądż ma złą długość)!");
            PacjentMiasto_urField.setText(null);
            return;
        } else {
            stm.setString(1, String.valueOf(PrzychodniaController.this.PacjentImieField.getText()));
            stm.setString(2, String.valueOf(PrzychodniaController.this.PacjentNazwiskoField.getText()));
            stm.setString(3, String.valueOf(PrzychodniaController.this.PacjentTelefonField.getText()));
            stm.setString(4, String.valueOf(PrzychodniaController.this.PacjentEmailField.getText()));
            stm.setString(5, String.valueOf(PrzychodniaController.this.PacjentData_urDatePicker.getEditor().getText()));
            stm.setString(6, String.valueOf(PrzychodniaController.this.PacjentMiasto_urField.getText()));
            stm.setInt(7, Integer.parseInt(id));
            stm.execute();
            PacjentLadujButton.fire();
        }
        conn.close();
    }

    @FXML
    public void deletePacjent(ActionEvent actionEvent) throws SQLException, NullPointerException, Exception {
        String deleteQuery = "DELETE FROM pacjent WHERE id = ";
        Pacjent getSelectedRow = PacjentTableView.getSelectionModel().getSelectedItem();
        Connection conn = DbConnection.connect("Projekt4.sqlite",
                "base/Przychodnia_lekarska_CREATE.sql", "base/Przychodnia_lekarska_INSERT.sql");
        if (!getSelectedRow.toString().equals("")) {
            String id = this.PacjentIdField.getText();
            deleteQuery += id + "; ";
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Potwierdzenie usunięcia");
            alert.setHeaderText("Chcesz usunąć pacjenta?");
            alert.setContentText("" + getSelectedRow.getNazwisko() + " " + getSelectedRow.getImie());
            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK) {
                PreparedStatement stm = conn.prepareStatement(deleteQuery);
                stm.execute();
                PacjentLadujButton.fire();
                stm.close();
            }
        }
        conn.close();
    }

    @FXML
    private void clearPacjent(ActionEvent event) {
        this.PacjentIdField.setText(null);
        this.PacjentImieField.setText(null);
        this.PacjentNazwiskoField.setText(null);
        this.PacjentTelefonField.setText(null);
        this.PacjentEmailField.setText(null);
        this.PacjentMiasto_urField.setText(null);
        this.PacjentData_urDatePicker.setValue(null);
    }

    @FXML
    public void addChoroba(ActionEvent actionEvent) throws Exception {
        String insertQuery = "INSERT INTO choroba(nazwa, opis, pochodzenie, nr_medyczny, ilosc_mozliwych_szczepien) VALUES (?,?,?,?,?);";
        String checkUniqueNr_medyczny = "SELECT id FROM choroba WHERE nr_medyczny = ?;";
        Connection conn = DbConnection.connect("Projekt4.sqlite",
                "base/Przychodnia_lekarska_CREATE.sql", "base/Przychodnia_lekarska_INSERT.sql");
        PreparedStatement stm = conn.prepareStatement(insertQuery);
        if (!isName(this.ChorobaNazwaField.getText()) || !isValidLen(this.ChorobaNazwaField.getText(), 50)) {
            setAlertError("Błędne dane!", "Nazwa nie jest poprawna (zawiera niedozwolone znaki bądż ma złą długość)!");
            ChorobaNazwaField.setText(null);
            return;
        } else if (!isLetters(this.ChorobaOpisField.getText()) || !isValidLen(this.ChorobaOpisField.getText(), 200)) {
            setAlertError("Błędne dane!", "Opis nie jest poprawny (zawiera niedozwolone znaki bądż ma złą długość)!");
            ChorobaOpisField.setText(null);
            return;
        } else if (!isName(this.ChorobaPochodzenieField.getText()) || !isValidLen(this.ChorobaPochodzenieField.getText(), 40)) {
            setAlertError("Błędne dane!", "Pochodzenie nie jest poprawne (zawiera niedozwolone znaki bądż ma złą długość)!");
            ChorobaPochodzenieField.setText(null);
            return;
        } else if (!isDouble(this.ChorobaNr_medycznyField.getText()) || !isUnique(this.ChorobaNr_medycznyField.getText(), checkUniqueNr_medyczny)) {
            setAlertError("Błędne dane!", "Nr medyczny nie jest poprawny (zawiera niedozwolone znaki bądż ma złą długość)!");
            ChorobaNr_medycznyField.setText(null);
            return;
        } else if (!isPositiveInteger(this.ChorobaIlosc_mozliwych_szczepienField.getText())) {
            setAlertError("Błędne dane!", "Ilość możliwych szczepień nie jest poprawna (zawiera niedozwolone znaki bądż ma złą długość)!");
            ChorobaNr_medycznyField.setText(null);
            return;
        } else {
            stm.setString(1, String.valueOf(PrzychodniaController.this.ChorobaNazwaField.getText()));
            stm.setString(2, String.valueOf(PrzychodniaController.this.ChorobaOpisField.getText()));
            stm.setString(3, String.valueOf(PrzychodniaController.this.ChorobaPochodzenieField.getText()));
            stm.setDouble(4, Double.valueOf(PrzychodniaController.this.ChorobaNr_medycznyField.getText()));
            stm.setInt(5, Integer.valueOf(PrzychodniaController.this.ChorobaIlosc_mozliwych_szczepienField.getText()));
            stm.execute();
            ChorobaLadujButton.fire();
        }
        conn.close();
    }

    @FXML
    public void editChoroba(ActionEvent actionEvent) throws Exception {
        String updateQuery = "UPDATE choroba SET nazwa = ?, opis = ?, pochodzenie = ?, nr_medyczny = ?, ilosc_mozliwych_szczepien = ? "
                + " WHERE id = ?;";
        Choroba getSelectedRow = ChorobaTableView.getSelectionModel().getSelectedItem();
        Connection conn = DbConnection.connect("Projekt4.sqlite",
                "base/Przychodnia_lekarska_CREATE.sql", "base/Przychodnia_lekarska_INSERT.sql");
        if (!getSelectedRow.toString().equals("")) {
            String id = this.ChorobaIdField.getText();
            PreparedStatement stm = conn.prepareStatement(updateQuery);
            if (!isName(this.ChorobaNazwaField.getText()) || !isValidLen(this.ChorobaNazwaField.getText(), 50)) {
                setAlertError("Błędne dane!", "Nazwa nie jest poprawna (zawiera niedozwolone znaki bądż ma złą długość)!");
                ChorobaNazwaField.setText(null);
                return;
            } else if (!isLetters(this.ChorobaOpisField.getText()) || !isValidLen(this.ChorobaOpisField.getText(), 200)) {
                setAlertError("Błędne dane!", "Opis nie jest poprawny (zawiera niedozwolone znaki bądż ma złą długość)!");
                ChorobaOpisField.setText(null);
                return;
            } else if (!isName(this.ChorobaPochodzenieField.getText()) || !isValidLen(this.ChorobaPochodzenieField.getText(), 40)) {
                setAlertError("Błędne dane!", "Pochodzenie nie jest poprawne (zawiera niedozwolone znaki bądż ma złą długość)!");
                ChorobaPochodzenieField.setText(null);
                return;
            } else if (!isDouble(this.ChorobaNr_medycznyField.getText())) {
                setAlertError("Błędne dane!", "Nr medyczny nie jest poprawny (zawiera niedozwolone znaki bądż ma złą długość)!");
                ChorobaNr_medycznyField.setText(null);
                return;
            } else if (!isPositiveInteger(this.ChorobaIlosc_mozliwych_szczepienField.getText())) {
                setAlertError("Błędne dane!", "Ilość możliwych szczepień nie jest poprawna (zawiera niedozwolone znaki bądż ma złą długość)!");
                ChorobaIlosc_mozliwych_szczepienField.setText(null);
                return;
            } else {
                stm.setString(1, String.valueOf(PrzychodniaController.this.ChorobaNazwaField.getText()));
                stm.setString(2, String.valueOf(PrzychodniaController.this.ChorobaOpisField.getText()));
                stm.setString(3, String.valueOf(PrzychodniaController.this.ChorobaPochodzenieField.getText()));
                stm.setDouble(4, Double.valueOf(PrzychodniaController.this.ChorobaNr_medycznyField.getText()));
                stm.setInt(5, Integer.valueOf(PrzychodniaController.this.ChorobaIlosc_mozliwych_szczepienField.getText()));
                stm.setInt(6, Integer.parseInt(id));
                stm.execute();
                ChorobaLadujButton.fire();
                stm.close();
            }
        }
        conn.close();
    }

    @FXML
    public void deleteChoroba(ActionEvent actionEvent) throws SQLException, NullPointerException, Exception {
        String deleteQuery = "DELETE FROM choroba WHERE id = ";
        Choroba getSelectedRow = ChorobaTableView.getSelectionModel().getSelectedItem();
        Connection conn = DbConnection.connect("Projekt4.sqlite",
                "base/Przychodnia_lekarska_CREATE.sql", "base/Przychodnia_lekarska_INSERT.sql");
        if (!getSelectedRow.toString().equals("")) {
            String id = this.ChorobaIdField.getText();
            deleteQuery += id + "; ";
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Potwierdzenie usunięcia");
            alert.setHeaderText("Chcesz usunąć chorobe?");
            alert.setContentText("" + getSelectedRow.getNazwa());
            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK) {
                PreparedStatement stm = conn.prepareStatement(deleteQuery);
                stm.execute();
                ChorobaLadujButton.fire();
                stm.close();
            }
        }
        conn.close();
    }

    @FXML
    private void clearChoroba(ActionEvent event) {
        this.ChorobaNazwaField.setText(null);
        this.ChorobaOpisField.setText(null);
        this.ChorobaPochodzenieField.setText(null);
        this.ChorobaNr_medycznyField.setText(null);
        this.ChorobaIlosc_mozliwych_szczepienField.setText(null);
    }

    @FXML
    public void addWizyta(ActionEvent actionEvent) throws Exception {
        String lekarz = null, pacjent = null, lekarz_id = null, pacjent_id = null;
        String insertQuery = "INSERT INTO wizyta(lekarz_id, pacjent_id, data_wizyty) VALUES (?,?,?);";
        String lekarzQuery = "SELECT id FROM lekarz WHERE nazwisko = ? AND imie = ?;";
        String pacjentQuery = "SELECT id FROM pacjent WHERE nazwisko = ? AND imie = ?;";
        Connection conn = DbConnection.connect("Projekt4.sqlite",
                "base/Przychodnia_lekarska_CREATE.sql", "base/Przychodnia_lekarska_INSERT.sql");
        PreparedStatement stm = conn.prepareStatement(insertQuery);
        if (this.WizytaLekarz_idComboBox.getValue() == null || this.WizytaPacjent_idComboBox.getValue() == null) {
            setAlertError("Niepoprawny wybór", "Wybierz wszystkie pola!");
            return;
        } else if (this.WizytaData_wizytyDatePicker.getValue() == null) {
            setAlertError("Niepoprawny wybór!", "Data wizyty jest pusta!");
            return;
        } else {
            lekarz = WizytaLekarz_idComboBox.getValue().toString();
            String[] sp = lekarz.split(" ");
            String lekarzNazwisko = sp[0], lekarzImie = sp[1];
            PreparedStatement lek = conn.prepareStatement(lekarzQuery);
            lek.setString(1, lekarzNazwisko);
            lek.setString(2, lekarzImie);
            ResultSet rs1 = lek.executeQuery();
            while (rs1.next()) {
                lekarz_id = rs1.getString(1);
            }
            pacjent = WizytaPacjent_idComboBox.getValue().toString();
            sp = pacjent.split(" ");
            String pacjentNazwisko = sp[0], pacjentImie = sp[1];
            PreparedStatement pac = conn.prepareStatement(pacjentQuery);
            pac.setString(1, pacjentNazwisko);
            pac.setString(2, pacjentImie);
            ResultSet rs2 = pac.executeQuery();
            while (rs2.next()) {
                pacjent_id = rs2.getString(1);
            }
            stm.setInt(1, Integer.parseInt(lekarz_id));
            stm.setInt(2, Integer.parseInt(pacjent_id));
            stm.setString(3, String.valueOf(PrzychodniaController.this.WizytaData_wizytyDatePicker.getEditor().getText()));
            stm.execute();
            WizytaLadujButton.fire();
        }
        conn.close();
    }

    @FXML
    public void editWizyta(ActionEvent actionEvent) throws Exception {
        String lekarz = null, pacjent = null, lekarz_id = null, pacjent_id = null;
        String updateQuery = "UPDATE wizyta SET lekarz_id = ?, pacjent_id = ?, data_wizyty = ? "
                + " WHERE id = ?;";
        String lekarzQuery = "SELECT id FROM lekarz WHERE nazwisko = ? AND imie = ?;";
        String pacjentQuery = "SELECT id FROM pacjent WHERE nazwisko = ? AND imie = ?;";
        Wizyta getSelectedRow = WizytaTableView.getSelectionModel().getSelectedItem();
        Connection conn = DbConnection.connect("Projekt4.sqlite",
                "base/Przychodnia_lekarska_CREATE.sql", "base/Przychodnia_lekarska_INSERT.sql");
        if (!getSelectedRow.toString().equals("")) {
            PreparedStatement stm = conn.prepareStatement(updateQuery);
            if (this.WizytaLekarz_idComboBox.getValue() == null || this.WizytaPacjent_idComboBox.getValue() == null) {
                setAlertError("Niepoprawny wybór", "Wybierz wszystkie pola!");
                return;
            } else if (this.WizytaData_wizytyDatePicker.getValue() == null) {
                setAlertError("Niepoprawny wybór!", "Data wizyty jest pusta!");
                return;
            } else {
                String id = this.WizytaIdField.getText();
                lekarz = WizytaLekarz_idComboBox.getValue().toString();
                String[] sp = lekarz.split(" ");
                String lekarzNazwisko = sp[0], lekarzImie = sp[1];
                PreparedStatement lek = conn.prepareStatement(lekarzQuery);
                lek.setString(1, lekarzNazwisko);
                lek.setString(2, lekarzImie);
                ResultSet rs1 = lek.executeQuery();
                while (rs1.next()) {
                    lekarz_id = rs1.getString(1);
                }
                pacjent = WizytaPacjent_idComboBox.getValue().toString();
                sp = pacjent.split(" ");
                String pacjentNazwisko = sp[0], pacjentImie = sp[1];
                PreparedStatement pac = conn.prepareStatement(pacjentQuery);
                pac.setString(1, pacjentNazwisko);
                pac.setString(2, pacjentImie);
                ResultSet rs2 = pac.executeQuery();
                while (rs2.next()) {
                    pacjent_id = rs2.getString(1);
                }
                stm.setInt(1, Integer.parseInt(lekarz_id));
                stm.setInt(2, Integer.parseInt(pacjent_id));
                stm.setString(3, String.valueOf(PrzychodniaController.this.WizytaData_wizytyDatePicker.getEditor().getText()));
                stm.setInt(4, Integer.parseInt(id));
                stm.execute();
                WizytaLadujButton.fire();
                stm.close();
            }
        }
        conn.close();
    }

    @FXML
    public void deleteWizyta(ActionEvent actionEvent) throws SQLException, NullPointerException, Exception {
        String deleteQuery = "DELETE FROM wizyta WHERE id = ";
        Wizyta getSelectedRow = WizytaTableView.getSelectionModel().getSelectedItem();
        Connection conn = DbConnection.connect("Projekt4.sqlite",
                "base/Przychodnia_lekarska_CREATE.sql", "base/Przychodnia_lekarska_INSERT.sql");
        if (!getSelectedRow.toString().equals("")) {
            String id = this.WizytaIdField.getText();
            deleteQuery += id + "; ";
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Potwierdzenie usunięcia");
            alert.setHeaderText("Chcesz usunąć wizyte?");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK) {
                PreparedStatement stm = conn.prepareStatement(deleteQuery);
                stm.execute();
                WizytaLadujButton.fire();
                stm.close();
            }
        }
        conn.close();
    }

    @FXML
    private void clearWizyta(ActionEvent event) {
        this.WizytaLekarz_idComboBox.setValue(null);
        this.WizytaPacjent_idComboBox.setValue(null);
        this.WizytaData_wizytyDatePicker.setValue(null);
    }

    @FXML
    public void addHistoria(ActionEvent actionEvent) throws Exception {
        String wizyta = null, choroba = null, wizyta_id = null, choroba_id = null;
        String insertQuery = "INSERT INTO historia_chorob(wizyta_id, choroba_id, zalecenia, oplata) VALUES (?,?,?,?);";
        String wizytaQuery = "SELECT w.id FROM wizyta AS w JOIN pacjent AS p ON w.pacjent_id = p.id WHERE p.nazwisko = ? AND p.imie = ?;";
        String chorobaQuery = "SELECT id FROM choroba WHERE nazwa = ?;";
        Connection conn = DbConnection.connect("Projekt4.sqlite",
                "base/Przychodnia_lekarska_CREATE.sql", "base/Przychodnia_lekarska_INSERT.sql");
        PreparedStatement stm = conn.prepareStatement(insertQuery);
        if (this.HistoriaWizyta_idComboBox.getValue() == null || this.HistoriaChoroba_idComboBox.getValue() == null) {
            setAlertError("Niepoprawny wybór", "Wybierz wszystkie pola!");
            return;
        } else if (!isLetters(this.HistoriaZaleceniaField.getText()) || !isValidLen(this.HistoriaZaleceniaField.getText(), 200)) {
            setAlertError("Błędne dane!", "Zalecenie nie są poprawne (zawiera niedozwolone znaki bądż ma złą długość)!");
            HistoriaZaleceniaField.setText(null);
            return;
        } else if (!isMoney(this.HistoriaOplataField.getText())) {
            setAlertError("Błędne dane!", "Opłata nie jest poprawna (zawiera niedozwolone znaki bądż ma złą długość)!");
            HistoriaOplataField.setText(null);
            return;
        } else {
            wizyta = HistoriaWizyta_idComboBox.getValue().toString();
            String[] sp = wizyta.split(" ");
            String wizytaNazwisko = sp[0], wizytaImie = sp[1];
            PreparedStatement wiz = conn.prepareStatement(wizytaQuery);
            wiz.setString(1, wizytaNazwisko);
            wiz.setString(2, wizytaImie);
            ResultSet rs1 = wiz.executeQuery();
            while (rs1.next()) {
                wizyta_id = rs1.getString(1);
            }
            choroba = HistoriaChoroba_idComboBox.getValue().toString();
            PreparedStatement cho = conn.prepareStatement(chorobaQuery);
            cho.setString(1, choroba);
            ResultSet rs2 = cho.executeQuery();
            while (rs2.next()) {
                choroba_id = rs2.getString(1);
            }
            stm.setInt(1, Integer.parseInt(wizyta_id));
            stm.setInt(2, Integer.parseInt(choroba_id));
            stm.setString(3, String.valueOf(PrzychodniaController.this.HistoriaZaleceniaField.getText()));
            stm.setDouble(4, Double.valueOf(PrzychodniaController.this.HistoriaOplataField.getText()));
            stm.execute();
            HistoriaLadujButton.fire();
        }
        conn.close();
    }

    //TODO
    @FXML
    public void editHistoria(ActionEvent actionEvent) throws Exception {
        String wizyta = null, wizyta_id = null;
        String updateQuery = "UPDATE historia_chorob SET zalecenia = ?, oplata = ? "
                + " WHERE wizyta_id = ?;";
        String wizytaQuery = "SELECT w.id FROM wizyta AS w JOIN pacjent AS p ON w.pacjent_id = p.id WHERE p.nazwisko = ? AND p.imie = ?;";
        Historia getSelectedRow = HistoriaTableView.getSelectionModel().getSelectedItem();
        Connection conn = DbConnection.connect("Projekt4.sqlite",
                "base/Przychodnia_lekarska_CREATE.sql", "base/Przychodnia_lekarska_INSERT.sql");
        if (!getSelectedRow.toString().equals("")) {
            PreparedStatement stm = conn.prepareStatement(updateQuery);
            if (this.HistoriaWizyta_idComboBox.getValue() == null || this.HistoriaChoroba_idComboBox.getValue() == null) {
                setAlertError("Niepoprawny wybór", "Wybierz wszystkie pola!");
                return;
            } else if (!isLetters(this.HistoriaZaleceniaField.getText()) || !isValidLen(this.HistoriaZaleceniaField.getText(), 200)) {
                setAlertError("Błędne dane!", "Zalecenie nie są poprawne (zawiera niedozwolone znaki bądż ma złą długość)!");
                HistoriaZaleceniaField.setText(null);
                return;
            } else if (!isMoney(this.HistoriaOplataField.getText())) {
                setAlertError("Błędne dane!", "Opłata nie jest poprawna (zawiera niedozwolone znaki bądż ma złą długość)!");
                HistoriaOplataField.setText(null);
                return;
            } else {
                wizyta = HistoriaWizyta_idComboBox.getValue().toString();
                String[] sp = wizyta.split(" ");
                String wizytaNazwisko = sp[0], wizytaImie = sp[1];
                PreparedStatement wiz = conn.prepareStatement(wizytaQuery);
                wiz.setString(1, wizytaNazwisko);
                wiz.setString(2, wizytaImie);
                ResultSet rs1 = wiz.executeQuery();
                while (rs1.next()) {
                    wizyta_id = rs1.getString(1);
                }
                stm.setString(1, String.valueOf(PrzychodniaController.this.HistoriaZaleceniaField.getText()));
                stm.setDouble(2, Double.valueOf(PrzychodniaController.this.HistoriaOplataField.getText()));
                stm.setInt(3, Integer.parseInt(wizyta_id));
                HistoriaLadujButton.fire();
                stm.close();
            }
        }
        conn.close();
    }

    @FXML
    public void deleteHistoria(ActionEvent actionEvent) throws SQLException, NullPointerException, Exception {
        String wizyta = null, wizyta_id = null;
        String deleteQuery = "DELETE FROM historia_chorob WHERE wizyta_id = ";
        String wizytaQuery = "SELECT w.id FROM wizyta AS w JOIN pacjent AS p ON w.pacjent_id = p.id WHERE p.nazwisko = ? AND p.imie = ?;";
        Historia getSelectedRow = HistoriaTableView.getSelectionModel().getSelectedItem();
        Connection conn = DbConnection.connect("Projekt4.sqlite",
                "base/Przychodnia_lekarska_CREATE.sql", "base/Przychodnia_lekarska_INSERT.sql");
        if (!getSelectedRow.toString().equals("")) {
            wizyta = HistoriaWizyta_idComboBox.getValue().toString();
            String[] sp = wizyta.split(" ");
            String wizytaNazwisko = sp[0], wizytaImie = sp[1];
            PreparedStatement wiz = conn.prepareStatement(wizytaQuery);
            wiz.setString(1, wizytaNazwisko);
            wiz.setString(2, wizytaImie);
            ResultSet rs1 = wiz.executeQuery();
            while (rs1.next()) {
                wizyta_id = rs1.getString(1);
            }
            deleteQuery += wizyta_id + ";";
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Potwierdzenie usunięcia");
            alert.setHeaderText("Chcesz usunąć wpis?");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK) {
                PreparedStatement stm = conn.prepareStatement(deleteQuery);
                stm.execute();
                HistoriaLadujButton.fire();
                stm.close();
            }
        }
        conn.close();
    }

    @FXML
    private void clearHistoria(ActionEvent event) {
        this.HistoriaWizyta_idComboBox.setValue(null);
        this.HistoriaChoroba_idComboBox.setValue(null);
        this.HistoriaZaleceniaField.setText(null);
        this.HistoriaOplataField.setText(null);
    }

    public void setAlertError(String type, String mssg) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(type);
        alert.setHeaderText(mssg);
        alert.showAndWait();
        return;
    }

    public boolean isUnique(String s, String query) throws Exception {
        PreparedStatement h = DbConnection.connect("Projekt4.sqlite",
                "base/Przychodnia_lekarska_CREATE.sql", "base/Przychodnia_lekarska_INSERT.sql").prepareStatement(query);
        int counter = 0;
        h.setString(1, s);
        ResultSet rs = h.executeQuery();
        while (rs.next()) {
            counter++;
        }
        if (counter == 0)
            return true;
        else
            return false;
    }

    public final boolean isName(String s) {
        return s.matches("[,.;a-zA-Z ]+$");
    }

    public final boolean isLetters(String s) {
        return s.matches("[,.;a-zA-Z0-9 ]+$");
    }

    public final boolean isValidLen(String s, int max) {
        if (s.length() >= max || s.length() <= 0) {
            return false;
        }
        return true;
    }

    public final boolean isPhoneNumber(String s) {
        return s.matches("\\d{9}");
    }

    public final boolean isDouble(String s) {
        return s.matches("[0-9]{1,8}(.[0-9]{1,6})?");
    }

    public final boolean isMoney(String s) {
        return s.matches("[0-9]{1,8}(.[0-9]{1,2})?");
    }

    public final boolean isPositiveInteger(String s) {
        return s.matches("[0-9][0-9]*");
    }
}
