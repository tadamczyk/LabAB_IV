﻿namespace Projekt5
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.projekt5DataSet = new Projekt5.Projekt5DataSet();
            this.LekarzLabel = new System.Windows.Forms.Label();
            this.LekarzList = new System.Windows.Forms.ListBox();
            this.PacjentList = new System.Windows.Forms.ListBox();
            this.PacjentLabel = new System.Windows.Forms.Label();
            this.Imie = new System.Windows.Forms.TextBox();
            this.Telefon = new System.Windows.Forms.TextBox();
            this.Data_ur = new System.Windows.Forms.TextBox();
            this.Miasto = new System.Windows.Forms.TextBox();
            this.Email = new System.Windows.Forms.TextBox();
            this.Nazwisko = new System.Windows.Forms.TextBox();
            this.LekarzAddBtn = new System.Windows.Forms.Button();
            this.PacjentAddBtn = new System.Windows.Forms.Button();
            this.LekarzUpdBtn = new System.Windows.Forms.Button();
            this.PacjentUpdBtn = new System.Windows.Forms.Button();
            this.PacjentDelBtn = new System.Windows.Forms.Button();
            this.LekarzDelBtn = new System.Windows.Forms.Button();
            this.PacjentShowBtn = new System.Windows.Forms.Button();
            this.LekarzShowBtn = new System.Windows.Forms.Button();
            this.ChorobaList = new System.Windows.Forms.ListBox();
            this.ChorobaLabel = new System.Windows.Forms.Label();
            this.ChorobaNazwa = new System.Windows.Forms.TextBox();
            this.ChorobaOpis = new System.Windows.Forms.TextBox();
            this.ChorobaPochodzenie = new System.Windows.Forms.TextBox();
            this.ChorobaNr_medyczny = new System.Windows.Forms.TextBox();
            this.ChorobaCzy_szczepienie = new System.Windows.Forms.TextBox();
            this.ChorobaShowBtn = new System.Windows.Forms.Button();
            this.ChorobaDelBtn = new System.Windows.Forms.Button();
            this.ChorobaUpdBtn = new System.Windows.Forms.Button();
            this.ChorobaAddBtn = new System.Windows.Forms.Button();
            this.WizytaList = new System.Windows.Forms.ListBox();
            this.WizytaLabel = new System.Windows.Forms.Label();
            this.projekt5DataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.chorobaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.chorobaTableAdapter = new Projekt5.Projekt5DataSetTableAdapters.ChorobaTableAdapter();
            this.WizytaLekarzList = new System.Windows.Forms.ListBox();
            this.WizytaLekarzLabel = new System.Windows.Forms.Label();
            this.WizytaPacjentLabel = new System.Windows.Forms.Label();
            this.WizytaPacjentList = new System.Windows.Forms.ListBox();
            this.WizytaOplata = new System.Windows.Forms.TextBox();
            this.WizytaZalecenia = new System.Windows.Forms.TextBox();
            this.WizytaData_wizyty = new System.Windows.Forms.TextBox();
            this.WizytaShowBtn = new System.Windows.Forms.Button();
            this.WizytaDelBtn = new System.Windows.Forms.Button();
            this.WizytaUpdBtn = new System.Windows.Forms.Button();
            this.WizytaAddBtn = new System.Windows.Forms.Button();
            this.HistoriaList = new System.Windows.Forms.ListBox();
            this.HistoriaLabel = new System.Windows.Forms.Label();
            this.HistoriaWizytaList = new System.Windows.Forms.ListBox();
            this.HistoriaWizytaLabel = new System.Windows.Forms.Label();
            this.HistoriaChorobaList = new System.Windows.Forms.ListBox();
            this.HistoriaChorobaLabel = new System.Windows.Forms.Label();
            this.HistoriaShowBtn = new System.Windows.Forms.Button();
            this.HistoriaDelBtn = new System.Windows.Forms.Button();
            this.HistoriaUpdBtn = new System.Windows.Forms.Button();
            this.HistoriaAddBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.projekt5DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.projekt5DataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chorobaBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // projekt5DataSet
            // 
            this.projekt5DataSet.DataSetName = "Projekt5DataSet";
            this.projekt5DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // LekarzLabel
            // 
            this.LekarzLabel.AutoSize = true;
            this.LekarzLabel.Location = new System.Drawing.Point(12, 9);
            this.LekarzLabel.Name = "LekarzLabel";
            this.LekarzLabel.Size = new System.Drawing.Size(45, 13);
            this.LekarzLabel.TabIndex = 0;
            this.LekarzLabel.Text = "Lekarze";
            // 
            // LekarzList
            // 
            this.LekarzList.FormattingEnabled = true;
            this.LekarzList.Location = new System.Drawing.Point(12, 25);
            this.LekarzList.Name = "LekarzList";
            this.LekarzList.Size = new System.Drawing.Size(106, 173);
            this.LekarzList.TabIndex = 1;
            this.LekarzList.SelectedIndexChanged += new System.EventHandler(this.LekarzList_SelectedIndexChanged);
            // 
            // PacjentList
            // 
            this.PacjentList.FormattingEnabled = true;
            this.PacjentList.Location = new System.Drawing.Point(143, 25);
            this.PacjentList.Name = "PacjentList";
            this.PacjentList.Size = new System.Drawing.Size(106, 173);
            this.PacjentList.TabIndex = 3;
            this.PacjentList.SelectedIndexChanged += new System.EventHandler(this.PacjentList_SelectedIndexChanged);
            // 
            // PacjentLabel
            // 
            this.PacjentLabel.AutoSize = true;
            this.PacjentLabel.Location = new System.Drawing.Point(143, 9);
            this.PacjentLabel.Name = "PacjentLabel";
            this.PacjentLabel.Size = new System.Drawing.Size(48, 13);
            this.PacjentLabel.TabIndex = 2;
            this.PacjentLabel.Text = "Pacjenci";
            // 
            // Imie
            // 
            this.Imie.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.Imie.Location = new System.Drawing.Point(12, 216);
            this.Imie.Name = "Imie";
            this.Imie.Size = new System.Drawing.Size(106, 20);
            this.Imie.TabIndex = 4;
            this.Imie.Text = "Wpisz imię";
            // 
            // Telefon
            // 
            this.Telefon.Location = new System.Drawing.Point(143, 216);
            this.Telefon.Name = "Telefon";
            this.Telefon.Size = new System.Drawing.Size(106, 20);
            this.Telefon.TabIndex = 6;
            this.Telefon.Text = "Wpisz telefon";
            // 
            // Data_ur
            // 
            this.Data_ur.Location = new System.Drawing.Point(12, 268);
            this.Data_ur.Name = "Data_ur";
            this.Data_ur.Size = new System.Drawing.Size(237, 20);
            this.Data_ur.TabIndex = 8;
            this.Data_ur.Text = "Wpisz datę urodzenia";
            // 
            // Miasto
            // 
            this.Miasto.Location = new System.Drawing.Point(12, 294);
            this.Miasto.Name = "Miasto";
            this.Miasto.Size = new System.Drawing.Size(237, 20);
            this.Miasto.TabIndex = 9;
            this.Miasto.Text = "Wpisz miejsce urodzenia";
            // 
            // Email
            // 
            this.Email.Location = new System.Drawing.Point(143, 242);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(106, 20);
            this.Email.TabIndex = 7;
            this.Email.Text = "Wpisz e-mail";
            // 
            // Nazwisko
            // 
            this.Nazwisko.Location = new System.Drawing.Point(12, 242);
            this.Nazwisko.Name = "Nazwisko";
            this.Nazwisko.Size = new System.Drawing.Size(106, 20);
            this.Nazwisko.TabIndex = 5;
            this.Nazwisko.Text = "Wpisz nazwisko";
            // 
            // LekarzAddBtn
            // 
            this.LekarzAddBtn.BackColor = System.Drawing.Color.Yellow;
            this.LekarzAddBtn.Location = new System.Drawing.Point(12, 328);
            this.LekarzAddBtn.Name = "LekarzAddBtn";
            this.LekarzAddBtn.Size = new System.Drawing.Size(106, 23);
            this.LekarzAddBtn.TabIndex = 10;
            this.LekarzAddBtn.Text = "Dodaj lekarza";
            this.LekarzAddBtn.UseVisualStyleBackColor = false;
            this.LekarzAddBtn.Click += new System.EventHandler(this.LekarzAddBtn_Click);
            // 
            // PacjentAddBtn
            // 
            this.PacjentAddBtn.BackColor = System.Drawing.Color.Yellow;
            this.PacjentAddBtn.Location = new System.Drawing.Point(143, 328);
            this.PacjentAddBtn.Name = "PacjentAddBtn";
            this.PacjentAddBtn.Size = new System.Drawing.Size(106, 23);
            this.PacjentAddBtn.TabIndex = 11;
            this.PacjentAddBtn.Text = "Dodaj pacjenta";
            this.PacjentAddBtn.UseVisualStyleBackColor = false;
            this.PacjentAddBtn.Click += new System.EventHandler(this.PacjentAddBtn_Click);
            // 
            // LekarzUpdBtn
            // 
            this.LekarzUpdBtn.BackColor = System.Drawing.Color.Chartreuse;
            this.LekarzUpdBtn.Location = new System.Drawing.Point(12, 357);
            this.LekarzUpdBtn.Name = "LekarzUpdBtn";
            this.LekarzUpdBtn.Size = new System.Drawing.Size(106, 23);
            this.LekarzUpdBtn.TabIndex = 12;
            this.LekarzUpdBtn.Text = "Aktualizuj lekarza";
            this.LekarzUpdBtn.UseVisualStyleBackColor = false;
            this.LekarzUpdBtn.Click += new System.EventHandler(this.LekarzUpdBtn_Click);
            // 
            // PacjentUpdBtn
            // 
            this.PacjentUpdBtn.BackColor = System.Drawing.Color.Chartreuse;
            this.PacjentUpdBtn.Location = new System.Drawing.Point(143, 357);
            this.PacjentUpdBtn.Name = "PacjentUpdBtn";
            this.PacjentUpdBtn.Size = new System.Drawing.Size(106, 23);
            this.PacjentUpdBtn.TabIndex = 13;
            this.PacjentUpdBtn.Text = "Aktualizuj pacjenta";
            this.PacjentUpdBtn.UseVisualStyleBackColor = false;
            this.PacjentUpdBtn.Click += new System.EventHandler(this.PacjentUpdBtn_Click);
            // 
            // PacjentDelBtn
            // 
            this.PacjentDelBtn.BackColor = System.Drawing.Color.Red;
            this.PacjentDelBtn.Location = new System.Drawing.Point(143, 386);
            this.PacjentDelBtn.Name = "PacjentDelBtn";
            this.PacjentDelBtn.Size = new System.Drawing.Size(106, 23);
            this.PacjentDelBtn.TabIndex = 15;
            this.PacjentDelBtn.Text = "Usuń pacjenta";
            this.PacjentDelBtn.UseVisualStyleBackColor = false;
            this.PacjentDelBtn.Click += new System.EventHandler(this.PacjentDelBtn_Click);
            // 
            // LekarzDelBtn
            // 
            this.LekarzDelBtn.BackColor = System.Drawing.Color.Red;
            this.LekarzDelBtn.Location = new System.Drawing.Point(12, 386);
            this.LekarzDelBtn.Name = "LekarzDelBtn";
            this.LekarzDelBtn.Size = new System.Drawing.Size(106, 23);
            this.LekarzDelBtn.TabIndex = 14;
            this.LekarzDelBtn.Text = "Usuń lekarza";
            this.LekarzDelBtn.UseVisualStyleBackColor = false;
            this.LekarzDelBtn.Click += new System.EventHandler(this.LekarzDelBtn_Click);
            // 
            // PacjentShowBtn
            // 
            this.PacjentShowBtn.BackColor = System.Drawing.SystemColors.Highlight;
            this.PacjentShowBtn.Location = new System.Drawing.Point(143, 415);
            this.PacjentShowBtn.Name = "PacjentShowBtn";
            this.PacjentShowBtn.Size = new System.Drawing.Size(106, 23);
            this.PacjentShowBtn.TabIndex = 17;
            this.PacjentShowBtn.Text = "Pokaż pacjenta";
            this.PacjentShowBtn.UseVisualStyleBackColor = false;
            this.PacjentShowBtn.Click += new System.EventHandler(this.PacjentShowBtn_Click);
            // 
            // LekarzShowBtn
            // 
            this.LekarzShowBtn.BackColor = System.Drawing.SystemColors.Highlight;
            this.LekarzShowBtn.Location = new System.Drawing.Point(12, 415);
            this.LekarzShowBtn.Name = "LekarzShowBtn";
            this.LekarzShowBtn.Size = new System.Drawing.Size(106, 23);
            this.LekarzShowBtn.TabIndex = 16;
            this.LekarzShowBtn.Text = "Pokaż lekarza";
            this.LekarzShowBtn.UseVisualStyleBackColor = false;
            this.LekarzShowBtn.Click += new System.EventHandler(this.LekarzShowBtn_Click);
            // 
            // ChorobaList
            // 
            this.ChorobaList.FormattingEnabled = true;
            this.ChorobaList.Location = new System.Drawing.Point(354, 25);
            this.ChorobaList.Name = "ChorobaList";
            this.ChorobaList.Size = new System.Drawing.Size(106, 290);
            this.ChorobaList.TabIndex = 19;
            this.ChorobaList.SelectedIndexChanged += new System.EventHandler(this.ChorobaList_SelectedIndexChanged);
            // 
            // ChorobaLabel
            // 
            this.ChorobaLabel.AutoSize = true;
            this.ChorobaLabel.Location = new System.Drawing.Point(354, 9);
            this.ChorobaLabel.Name = "ChorobaLabel";
            this.ChorobaLabel.Size = new System.Drawing.Size(85, 13);
            this.ChorobaLabel.TabIndex = 18;
            this.ChorobaLabel.Text = "Choroby w bazie";
            // 
            // ChorobaNazwa
            // 
            this.ChorobaNazwa.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.ChorobaNazwa.Location = new System.Drawing.Point(466, 25);
            this.ChorobaNazwa.Name = "ChorobaNazwa";
            this.ChorobaNazwa.Size = new System.Drawing.Size(106, 20);
            this.ChorobaNazwa.TabIndex = 20;
            this.ChorobaNazwa.Text = "Wpisz nazwe";
            // 
            // ChorobaOpis
            // 
            this.ChorobaOpis.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.ChorobaOpis.Location = new System.Drawing.Point(466, 51);
            this.ChorobaOpis.Name = "ChorobaOpis";
            this.ChorobaOpis.Size = new System.Drawing.Size(106, 20);
            this.ChorobaOpis.TabIndex = 21;
            this.ChorobaOpis.Text = "Wpisz opis";
            // 
            // ChorobaPochodzenie
            // 
            this.ChorobaPochodzenie.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.ChorobaPochodzenie.Location = new System.Drawing.Point(466, 77);
            this.ChorobaPochodzenie.Name = "ChorobaPochodzenie";
            this.ChorobaPochodzenie.Size = new System.Drawing.Size(106, 20);
            this.ChorobaPochodzenie.TabIndex = 22;
            this.ChorobaPochodzenie.Text = "Wpisz pochodzenie";
            // 
            // ChorobaNr_medyczny
            // 
            this.ChorobaNr_medyczny.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.ChorobaNr_medyczny.Location = new System.Drawing.Point(466, 103);
            this.ChorobaNr_medyczny.Name = "ChorobaNr_medyczny";
            this.ChorobaNr_medyczny.Size = new System.Drawing.Size(106, 20);
            this.ChorobaNr_medyczny.TabIndex = 23;
            this.ChorobaNr_medyczny.Text = "Wpisz nr medyczny";
            // 
            // ChorobaCzy_szczepienie
            // 
            this.ChorobaCzy_szczepienie.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.ChorobaCzy_szczepienie.Location = new System.Drawing.Point(466, 129);
            this.ChorobaCzy_szczepienie.Name = "ChorobaCzy_szczepienie";
            this.ChorobaCzy_szczepienie.Size = new System.Drawing.Size(106, 20);
            this.ChorobaCzy_szczepienie.TabIndex = 24;
            this.ChorobaCzy_szczepienie.Text = "Szczepionka?";
            // 
            // ChorobaShowBtn
            // 
            this.ChorobaShowBtn.BackColor = System.Drawing.SystemColors.Highlight;
            this.ChorobaShowBtn.Location = new System.Drawing.Point(354, 415);
            this.ChorobaShowBtn.Name = "ChorobaShowBtn";
            this.ChorobaShowBtn.Size = new System.Drawing.Size(106, 23);
            this.ChorobaShowBtn.TabIndex = 28;
            this.ChorobaShowBtn.Text = "Pokaż chorobe";
            this.ChorobaShowBtn.UseVisualStyleBackColor = false;
            this.ChorobaShowBtn.Click += new System.EventHandler(this.ChorobaShowBtn_Click);
            // 
            // ChorobaDelBtn
            // 
            this.ChorobaDelBtn.BackColor = System.Drawing.Color.Red;
            this.ChorobaDelBtn.Location = new System.Drawing.Point(354, 386);
            this.ChorobaDelBtn.Name = "ChorobaDelBtn";
            this.ChorobaDelBtn.Size = new System.Drawing.Size(106, 23);
            this.ChorobaDelBtn.TabIndex = 27;
            this.ChorobaDelBtn.Text = "Usuń chorobe";
            this.ChorobaDelBtn.UseVisualStyleBackColor = false;
            this.ChorobaDelBtn.Click += new System.EventHandler(this.ChorobaDelBtn_Click);
            // 
            // ChorobaUpdBtn
            // 
            this.ChorobaUpdBtn.BackColor = System.Drawing.Color.Chartreuse;
            this.ChorobaUpdBtn.Location = new System.Drawing.Point(354, 357);
            this.ChorobaUpdBtn.Name = "ChorobaUpdBtn";
            this.ChorobaUpdBtn.Size = new System.Drawing.Size(106, 23);
            this.ChorobaUpdBtn.TabIndex = 26;
            this.ChorobaUpdBtn.Text = "Aktualizuj chorobe";
            this.ChorobaUpdBtn.UseVisualStyleBackColor = false;
            this.ChorobaUpdBtn.Click += new System.EventHandler(this.ChorobaUpdBtn_Click);
            // 
            // ChorobaAddBtn
            // 
            this.ChorobaAddBtn.BackColor = System.Drawing.Color.Yellow;
            this.ChorobaAddBtn.Location = new System.Drawing.Point(354, 328);
            this.ChorobaAddBtn.Name = "ChorobaAddBtn";
            this.ChorobaAddBtn.Size = new System.Drawing.Size(106, 23);
            this.ChorobaAddBtn.TabIndex = 25;
            this.ChorobaAddBtn.Text = "Dodaj chorobe";
            this.ChorobaAddBtn.UseVisualStyleBackColor = false;
            this.ChorobaAddBtn.Click += new System.EventHandler(this.ChorobaAddBtn_Click);
            // 
            // WizytaList
            // 
            this.WizytaList.FormattingEnabled = true;
            this.WizytaList.Location = new System.Drawing.Point(674, 25);
            this.WizytaList.Name = "WizytaList";
            this.WizytaList.Size = new System.Drawing.Size(238, 173);
            this.WizytaList.TabIndex = 30;
            this.WizytaList.SelectedIndexChanged += new System.EventHandler(this.WizytaList_SelectedIndexChanged);
            // 
            // WizytaLabel
            // 
            this.WizytaLabel.AutoSize = true;
            this.WizytaLabel.Location = new System.Drawing.Point(674, 9);
            this.WizytaLabel.Name = "WizytaLabel";
            this.WizytaLabel.Size = new System.Drawing.Size(90, 13);
            this.WizytaLabel.TabIndex = 29;
            this.WizytaLabel.Text = "Wizyty pacjentów";
            // 
            // projekt5DataSetBindingSource
            // 
            this.projekt5DataSetBindingSource.DataSource = this.projekt5DataSet;
            this.projekt5DataSetBindingSource.Position = 0;
            // 
            // chorobaBindingSource
            // 
            this.chorobaBindingSource.DataMember = "Choroba";
            this.chorobaBindingSource.DataSource = this.projekt5DataSetBindingSource;
            // 
            // chorobaTableAdapter
            // 
            this.chorobaTableAdapter.ClearBeforeFill = true;
            // 
            // WizytaLekarzList
            // 
            this.WizytaLekarzList.FormattingEnabled = true;
            this.WizytaLekarzList.Location = new System.Drawing.Point(918, 25);
            this.WizytaLekarzList.Name = "WizytaLekarzList";
            this.WizytaLekarzList.Size = new System.Drawing.Size(238, 30);
            this.WizytaLekarzList.TabIndex = 33;
            // 
            // WizytaLekarzLabel
            // 
            this.WizytaLekarzLabel.AutoSize = true;
            this.WizytaLekarzLabel.Location = new System.Drawing.Point(915, 9);
            this.WizytaLekarzLabel.Name = "WizytaLekarzLabel";
            this.WizytaLekarzLabel.Size = new System.Drawing.Size(45, 13);
            this.WizytaLekarzLabel.TabIndex = 34;
            this.WizytaLekarzLabel.Text = "Lekarze";
            // 
            // WizytaPacjentLabel
            // 
            this.WizytaPacjentLabel.AutoSize = true;
            this.WizytaPacjentLabel.Location = new System.Drawing.Point(915, 61);
            this.WizytaPacjentLabel.Name = "WizytaPacjentLabel";
            this.WizytaPacjentLabel.Size = new System.Drawing.Size(48, 13);
            this.WizytaPacjentLabel.TabIndex = 36;
            this.WizytaPacjentLabel.Text = "Pacjenci";
            // 
            // WizytaPacjentList
            // 
            this.WizytaPacjentList.FormattingEnabled = true;
            this.WizytaPacjentList.Location = new System.Drawing.Point(918, 77);
            this.WizytaPacjentList.Name = "WizytaPacjentList";
            this.WizytaPacjentList.Size = new System.Drawing.Size(238, 30);
            this.WizytaPacjentList.TabIndex = 35;
            // 
            // WizytaOplata
            // 
            this.WizytaOplata.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.WizytaOplata.Location = new System.Drawing.Point(1050, 119);
            this.WizytaOplata.Name = "WizytaOplata";
            this.WizytaOplata.Size = new System.Drawing.Size(106, 20);
            this.WizytaOplata.TabIndex = 39;
            this.WizytaOplata.Text = "Wpisz opłatę";
            // 
            // WizytaZalecenia
            // 
            this.WizytaZalecenia.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.WizytaZalecenia.Location = new System.Drawing.Point(918, 154);
            this.WizytaZalecenia.Name = "WizytaZalecenia";
            this.WizytaZalecenia.Size = new System.Drawing.Size(238, 20);
            this.WizytaZalecenia.TabIndex = 38;
            this.WizytaZalecenia.Text = "Wpisz zalecenia";
            // 
            // WizytaData_wizyty
            // 
            this.WizytaData_wizyty.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.WizytaData_wizyty.Location = new System.Drawing.Point(918, 119);
            this.WizytaData_wizyty.Name = "WizytaData_wizyty";
            this.WizytaData_wizyty.Size = new System.Drawing.Size(106, 20);
            this.WizytaData_wizyty.TabIndex = 37;
            this.WizytaData_wizyty.Text = "Wpisz date wizyty";
            // 
            // WizytaShowBtn
            // 
            this.WizytaShowBtn.BackColor = System.Drawing.SystemColors.Highlight;
            this.WizytaShowBtn.Location = new System.Drawing.Point(1172, 135);
            this.WizytaShowBtn.Name = "WizytaShowBtn";
            this.WizytaShowBtn.Size = new System.Drawing.Size(106, 23);
            this.WizytaShowBtn.TabIndex = 43;
            this.WizytaShowBtn.Text = "Pokaż wizyte";
            this.WizytaShowBtn.UseVisualStyleBackColor = false;
            this.WizytaShowBtn.Click += new System.EventHandler(this.WizytaShowBtn_Click);
            // 
            // WizytaDelBtn
            // 
            this.WizytaDelBtn.BackColor = System.Drawing.Color.Red;
            this.WizytaDelBtn.Location = new System.Drawing.Point(1172, 106);
            this.WizytaDelBtn.Name = "WizytaDelBtn";
            this.WizytaDelBtn.Size = new System.Drawing.Size(106, 23);
            this.WizytaDelBtn.TabIndex = 42;
            this.WizytaDelBtn.Text = "Usuń wizyte";
            this.WizytaDelBtn.UseVisualStyleBackColor = false;
            this.WizytaDelBtn.Click += new System.EventHandler(this.WizytaDelBtn_Click);
            // 
            // WizytaUpdBtn
            // 
            this.WizytaUpdBtn.BackColor = System.Drawing.Color.Chartreuse;
            this.WizytaUpdBtn.Location = new System.Drawing.Point(1172, 77);
            this.WizytaUpdBtn.Name = "WizytaUpdBtn";
            this.WizytaUpdBtn.Size = new System.Drawing.Size(106, 23);
            this.WizytaUpdBtn.TabIndex = 41;
            this.WizytaUpdBtn.Text = "Aktualizuj wizyte";
            this.WizytaUpdBtn.UseVisualStyleBackColor = false;
            this.WizytaUpdBtn.Click += new System.EventHandler(this.WizytaUpdBtn_Click);
            // 
            // WizytaAddBtn
            // 
            this.WizytaAddBtn.BackColor = System.Drawing.Color.Yellow;
            this.WizytaAddBtn.Location = new System.Drawing.Point(1172, 48);
            this.WizytaAddBtn.Name = "WizytaAddBtn";
            this.WizytaAddBtn.Size = new System.Drawing.Size(106, 23);
            this.WizytaAddBtn.TabIndex = 40;
            this.WizytaAddBtn.Text = "Dodaj wizyte";
            this.WizytaAddBtn.UseVisualStyleBackColor = false;
            this.WizytaAddBtn.Click += new System.EventHandler(this.WizytaAddBtn_Click);
            // 
            // HistoriaList
            // 
            this.HistoriaList.FormattingEnabled = true;
            this.HistoriaList.Location = new System.Drawing.Point(674, 268);
            this.HistoriaList.Name = "HistoriaList";
            this.HistoriaList.Size = new System.Drawing.Size(350, 173);
            this.HistoriaList.TabIndex = 45;
            this.HistoriaList.SelectedIndexChanged += new System.EventHandler(this.HistoriaList_SelectedIndexChanged);
            // 
            // HistoriaLabel
            // 
            this.HistoriaLabel.AutoSize = true;
            this.HistoriaLabel.Location = new System.Drawing.Point(674, 252);
            this.HistoriaLabel.Name = "HistoriaLabel";
            this.HistoriaLabel.Size = new System.Drawing.Size(78, 13);
            this.HistoriaLabel.TabIndex = 44;
            this.HistoriaLabel.Text = "Historia chorób";
            // 
            // HistoriaWizytaList
            // 
            this.HistoriaWizytaList.FormattingEnabled = true;
            this.HistoriaWizytaList.Location = new System.Drawing.Point(1040, 268);
            this.HistoriaWizytaList.Name = "HistoriaWizytaList";
            this.HistoriaWizytaList.Size = new System.Drawing.Size(238, 69);
            this.HistoriaWizytaList.TabIndex = 47;
            // 
            // HistoriaWizytaLabel
            // 
            this.HistoriaWizytaLabel.AutoSize = true;
            this.HistoriaWizytaLabel.Location = new System.Drawing.Point(1040, 252);
            this.HistoriaWizytaLabel.Name = "HistoriaWizytaLabel";
            this.HistoriaWizytaLabel.Size = new System.Drawing.Size(38, 13);
            this.HistoriaWizytaLabel.TabIndex = 46;
            this.HistoriaWizytaLabel.Text = "Wizyty";
            // 
            // HistoriaChorobaList
            // 
            this.HistoriaChorobaList.FormattingEnabled = true;
            this.HistoriaChorobaList.Location = new System.Drawing.Point(1040, 373);
            this.HistoriaChorobaList.Name = "HistoriaChorobaList";
            this.HistoriaChorobaList.Size = new System.Drawing.Size(238, 69);
            this.HistoriaChorobaList.TabIndex = 49;
            // 
            // HistoriaChorobaLabel
            // 
            this.HistoriaChorobaLabel.AutoSize = true;
            this.HistoriaChorobaLabel.Location = new System.Drawing.Point(1037, 357);
            this.HistoriaChorobaLabel.Name = "HistoriaChorobaLabel";
            this.HistoriaChorobaLabel.Size = new System.Drawing.Size(46, 13);
            this.HistoriaChorobaLabel.TabIndex = 48;
            this.HistoriaChorobaLabel.Text = "Choroby";
            // 
            // HistoriaShowBtn
            // 
            this.HistoriaShowBtn.BackColor = System.Drawing.SystemColors.Highlight;
            this.HistoriaShowBtn.Location = new System.Drawing.Point(786, 476);
            this.HistoriaShowBtn.Name = "HistoriaShowBtn";
            this.HistoriaShowBtn.Size = new System.Drawing.Size(106, 23);
            this.HistoriaShowBtn.TabIndex = 53;
            this.HistoriaShowBtn.Text = "Pokaż wpis";
            this.HistoriaShowBtn.UseVisualStyleBackColor = false;
            this.HistoriaShowBtn.Click += new System.EventHandler(this.HistoriaShowBtn_Click);
            // 
            // HistoriaDelBtn
            // 
            this.HistoriaDelBtn.BackColor = System.Drawing.Color.Red;
            this.HistoriaDelBtn.Location = new System.Drawing.Point(786, 447);
            this.HistoriaDelBtn.Name = "HistoriaDelBtn";
            this.HistoriaDelBtn.Size = new System.Drawing.Size(106, 23);
            this.HistoriaDelBtn.TabIndex = 52;
            this.HistoriaDelBtn.Text = "Usuń wpis";
            this.HistoriaDelBtn.UseVisualStyleBackColor = false;
            this.HistoriaDelBtn.Click += new System.EventHandler(this.HistoriaDelBtn_Click);
            // 
            // HistoriaUpdBtn
            // 
            this.HistoriaUpdBtn.BackColor = System.Drawing.Color.Chartreuse;
            this.HistoriaUpdBtn.Location = new System.Drawing.Point(674, 476);
            this.HistoriaUpdBtn.Name = "HistoriaUpdBtn";
            this.HistoriaUpdBtn.Size = new System.Drawing.Size(106, 23);
            this.HistoriaUpdBtn.TabIndex = 51;
            this.HistoriaUpdBtn.Text = "Aktualizuj wpis";
            this.HistoriaUpdBtn.UseVisualStyleBackColor = false;
            this.HistoriaUpdBtn.Click += new System.EventHandler(this.HistoriaUpdBtn_Click);
            // 
            // HistoriaAddBtn
            // 
            this.HistoriaAddBtn.BackColor = System.Drawing.Color.Yellow;
            this.HistoriaAddBtn.Location = new System.Drawing.Point(674, 447);
            this.HistoriaAddBtn.Name = "HistoriaAddBtn";
            this.HistoriaAddBtn.Size = new System.Drawing.Size(106, 23);
            this.HistoriaAddBtn.TabIndex = 50;
            this.HistoriaAddBtn.Text = "Dodaj wpis";
            this.HistoriaAddBtn.UseVisualStyleBackColor = false;
            this.HistoriaAddBtn.Click += new System.EventHandler(this.HistoriaAddBtn_Click);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1354, 520);
            this.Controls.Add(this.HistoriaShowBtn);
            this.Controls.Add(this.HistoriaDelBtn);
            this.Controls.Add(this.HistoriaUpdBtn);
            this.Controls.Add(this.HistoriaAddBtn);
            this.Controls.Add(this.HistoriaChorobaList);
            this.Controls.Add(this.HistoriaChorobaLabel);
            this.Controls.Add(this.HistoriaWizytaList);
            this.Controls.Add(this.HistoriaWizytaLabel);
            this.Controls.Add(this.HistoriaList);
            this.Controls.Add(this.HistoriaLabel);
            this.Controls.Add(this.WizytaShowBtn);
            this.Controls.Add(this.WizytaDelBtn);
            this.Controls.Add(this.WizytaUpdBtn);
            this.Controls.Add(this.WizytaAddBtn);
            this.Controls.Add(this.WizytaOplata);
            this.Controls.Add(this.WizytaZalecenia);
            this.Controls.Add(this.WizytaData_wizyty);
            this.Controls.Add(this.WizytaPacjentLabel);
            this.Controls.Add(this.WizytaPacjentList);
            this.Controls.Add(this.WizytaLekarzLabel);
            this.Controls.Add(this.WizytaLekarzList);
            this.Controls.Add(this.WizytaList);
            this.Controls.Add(this.WizytaLabel);
            this.Controls.Add(this.ChorobaShowBtn);
            this.Controls.Add(this.ChorobaDelBtn);
            this.Controls.Add(this.ChorobaUpdBtn);
            this.Controls.Add(this.ChorobaAddBtn);
            this.Controls.Add(this.ChorobaCzy_szczepienie);
            this.Controls.Add(this.ChorobaNr_medyczny);
            this.Controls.Add(this.ChorobaPochodzenie);
            this.Controls.Add(this.ChorobaOpis);
            this.Controls.Add(this.ChorobaNazwa);
            this.Controls.Add(this.ChorobaList);
            this.Controls.Add(this.ChorobaLabel);
            this.Controls.Add(this.PacjentShowBtn);
            this.Controls.Add(this.LekarzShowBtn);
            this.Controls.Add(this.PacjentDelBtn);
            this.Controls.Add(this.LekarzDelBtn);
            this.Controls.Add(this.PacjentUpdBtn);
            this.Controls.Add(this.LekarzUpdBtn);
            this.Controls.Add(this.PacjentAddBtn);
            this.Controls.Add(this.LekarzAddBtn);
            this.Controls.Add(this.Miasto);
            this.Controls.Add(this.Email);
            this.Controls.Add(this.Nazwisko);
            this.Controls.Add(this.Data_ur);
            this.Controls.Add(this.Telefon);
            this.Controls.Add(this.Imie);
            this.Controls.Add(this.PacjentList);
            this.Controls.Add(this.PacjentLabel);
            this.Controls.Add(this.LekarzList);
            this.Controls.Add(this.LekarzLabel);
            this.Name = "FormMain";
            this.Text = "Przychodnia lekarska";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FormMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.projekt5DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.projekt5DataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chorobaBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Projekt5DataSet projekt5DataSet;
        private System.Windows.Forms.Label LekarzLabel;
        private System.Windows.Forms.ListBox LekarzList;
        private System.Windows.Forms.ListBox PacjentList;
        private System.Windows.Forms.Label PacjentLabel;
        private System.Windows.Forms.TextBox Imie;
        private System.Windows.Forms.TextBox Telefon;
        private System.Windows.Forms.TextBox Data_ur;
        private System.Windows.Forms.TextBox Miasto;
        private System.Windows.Forms.TextBox Email;
        private System.Windows.Forms.TextBox Nazwisko;
        private System.Windows.Forms.Button LekarzAddBtn;
        private System.Windows.Forms.Button PacjentAddBtn;
        private System.Windows.Forms.Button LekarzUpdBtn;
        private System.Windows.Forms.Button PacjentUpdBtn;
        private System.Windows.Forms.Button PacjentDelBtn;
        private System.Windows.Forms.Button LekarzDelBtn;
        private System.Windows.Forms.Button PacjentShowBtn;
        private System.Windows.Forms.Button LekarzShowBtn;
        private System.Windows.Forms.ListBox ChorobaList;
        private System.Windows.Forms.Label ChorobaLabel;
        private System.Windows.Forms.TextBox ChorobaNazwa;
        private System.Windows.Forms.TextBox ChorobaOpis;
        private System.Windows.Forms.TextBox ChorobaPochodzenie;
        private System.Windows.Forms.TextBox ChorobaNr_medyczny;
        private System.Windows.Forms.TextBox ChorobaCzy_szczepienie;
        private System.Windows.Forms.Button ChorobaShowBtn;
        private System.Windows.Forms.Button ChorobaDelBtn;
        private System.Windows.Forms.Button ChorobaUpdBtn;
        private System.Windows.Forms.Button ChorobaAddBtn;
        private System.Windows.Forms.ListBox WizytaList;
        private System.Windows.Forms.Label WizytaLabel;
        private System.Windows.Forms.BindingSource projekt5DataSetBindingSource;
        private System.Windows.Forms.BindingSource chorobaBindingSource;
        private Projekt5DataSetTableAdapters.ChorobaTableAdapter chorobaTableAdapter;
        private System.Windows.Forms.ListBox WizytaLekarzList;
        private System.Windows.Forms.Label WizytaLekarzLabel;
        private System.Windows.Forms.Label WizytaPacjentLabel;
        private System.Windows.Forms.ListBox WizytaPacjentList;
        private System.Windows.Forms.TextBox WizytaOplata;
        private System.Windows.Forms.TextBox WizytaZalecenia;
        private System.Windows.Forms.TextBox WizytaData_wizyty;
        private System.Windows.Forms.Button WizytaShowBtn;
        private System.Windows.Forms.Button WizytaDelBtn;
        private System.Windows.Forms.Button WizytaUpdBtn;
        private System.Windows.Forms.Button WizytaAddBtn;
        private System.Windows.Forms.ListBox HistoriaList;
        private System.Windows.Forms.Label HistoriaLabel;
        private System.Windows.Forms.ListBox HistoriaWizytaList;
        private System.Windows.Forms.Label HistoriaWizytaLabel;
        private System.Windows.Forms.ListBox HistoriaChorobaList;
        private System.Windows.Forms.Label HistoriaChorobaLabel;
        private System.Windows.Forms.Button HistoriaShowBtn;
        private System.Windows.Forms.Button HistoriaDelBtn;
        private System.Windows.Forms.Button HistoriaUpdBtn;
        private System.Windows.Forms.Button HistoriaAddBtn;
    }
}

