DROP TABLE historia_chorob;

DROP TABLE wizyta;

DROP TABLE choroba;

DROP TABLE lekarz;

DROP TABLE pacjent;
