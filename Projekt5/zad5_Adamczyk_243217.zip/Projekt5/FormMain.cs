﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Globalization;
using System.Linq;
using System.Net.Mail;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Projekt5
{
    public partial class FormMain : Form
    {
        private readonly string connectionString;
        private SqlConnection connection;

        public FormMain()
        {
            InitializeComponent();

            connectionString =
                ConfigurationManager.ConnectionStrings["Projekt5.Properties.Settings.Projekt5ConnectionString"]
                    .ConnectionString;
        }

        private void FormMain_Load(object sender, EventArgs e)
        {
            UpdateAll();
        }

        private void UpdateAll()
        {
            UpdateLekarze();
            UpdatePacjenci();
            UpdateChoroby();
            UpdateWizyty();
            UpdateHistoria();
        }

        private bool IsValidString(string str)
        {
            return Regex.IsMatch(str, @"^[,.;a-zA-Z ]+$");
        }

        private bool IsValidLetter(string str)
        {
            return Regex.IsMatch(str, @"^[,.;0-9a-zA-Z ]+$");
        }

        private bool IsValidSurname(string str)
        {
            return Regex.IsMatch(str, @"^[-a-zA-Z]+$");
        }

        private bool IsValidPhoneNumber(string number)
        {
            return Regex.Match(number, @"^\+?(\d[\d-. ]+)?(\([\d-. ]+\))?[\d-. ]+\d$").Success;
        }

        private bool IsValidEmail(string email)
        {
            try
            {
                var addr = new MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }

        private bool IsValidDate(string date)
        {
            string[] formats = {"yyyy-MM-dd"};
            DateTime parsedDateTime;
            return DateTime.TryParseExact(date, formats, CultureInfo.InvariantCulture,
                DateTimeStyles.None, out parsedDateTime);
        }

        private bool IsValidDouble(string str)
        {
            double d;
            return double.TryParse(str, out d);
        }

        private bool IsValidBool(string str)
        {
            return (str == "0" || str == "1" || str == "true" || str == "false" || str == "True" || str == "False" ||
                    str == "TRUE" || str == "FALSE");
        }

        private bool IsValidMoney(string str)
        {
            return Regex.IsMatch(str, @"\d+(,\d{1,2})?");
        }

        private void UpdateLekarze()
        {
            var query = "SELECT Id, (Nazwisko + ' ' + Imie) AS Name, Telefon, Email, Data_ur, Miejsce_ur FROM Lekarz";
            using (connection = new SqlConnection(connectionString))
            using (var adapter = new SqlDataAdapter(query, connection))
            {
                var lekarzTable = new DataTable();
                adapter.Fill(lekarzTable);
                LekarzList.DisplayMember = "Name";
                LekarzList.ValueMember = "Id";
                LekarzList.DataSource = lekarzTable;
                WizytaLekarzList.DisplayMember = "Name";
                WizytaLekarzList.ValueMember = "Id";
                WizytaLekarzList.DataSource = lekarzTable;
            }
        }

        private void LekarzList_SelectedIndexChanged(object sender, EventArgs e)
        {
            var query = "SELECT Id, Imie, Nazwisko, Telefon, Email, Data_ur, Miejsce_ur FROM Lekarz WHERE Id=" +
                        LekarzList.SelectedValue;
            using (connection = new SqlConnection(connectionString))
            using (var command = new SqlCommand(query, connection))
            {
                connection.Open();
                command.CommandType = CommandType.Text;
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Imie.Text = (reader.GetString(1));
                        Nazwisko.Text = (reader.GetString(2));
                        Telefon.Text = (reader.GetString(3));
                        Email.Text = (reader.GetString(4));
                        var date = reader.GetDateTime(5).ToString("yyyy-MM-dd");
                        Data_ur.Text = date;
                        Miasto.Text = (reader.GetString(6));
                    }
                }
            }
        }

        private void UpdatePacjenci()
        {
            var query = "SELECT Id, (Nazwisko + ' ' + Imie) AS Name, Telefon, Email, Data_ur, Miasto_ur FROM Pacjent";
            using (connection = new SqlConnection(connectionString))
            using (var adapter = new SqlDataAdapter(query, connection))
            {
                var pacjentTable = new DataTable();
                adapter.Fill(pacjentTable);
                PacjentList.DisplayMember = "Name";
                PacjentList.ValueMember = "Id";
                PacjentList.DataSource = pacjentTable;
                WizytaPacjentList.DisplayMember = "Name";
                WizytaPacjentList.ValueMember = "Id";
                WizytaPacjentList.DataSource = pacjentTable;
            }
        }

        private void PacjentList_SelectedIndexChanged(object sender, EventArgs e)
        {
            var query = "SELECT Id, Imie, Nazwisko, Telefon, Email, Data_ur, Miasto_ur FROM Pacjent WHERE Id=" +
                        PacjentList.SelectedValue;
            using (connection = new SqlConnection(connectionString))
            using (var command = new SqlCommand(query, connection))
            {
                connection.Open();
                command.CommandType = CommandType.Text;
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Imie.Text = (reader.GetString(1));
                        Nazwisko.Text = (reader.GetString(2));
                        Telefon.Text = (reader.GetString(3));
                        Email.Text = (reader.GetString(4));
                        var date = reader.GetDateTime(5).ToString("yyyy-MM-dd");
                        Data_ur.Text = date;
                        Miasto.Text = (reader.GetString(6));
                    }
                }
            }
        }

        private void LekarzAddBtn_Click(object sender, EventArgs e)
        {
            var query = "INSERT INTO Lekarz VALUES(@Imie, @Nazwisko, @Telefon, @Email, @Data_ur, @Miasto_ur)";
            using (connection = new SqlConnection(connectionString))
            using (var command = new SqlCommand(query, connection))
            {
                var valid = true;
                connection.Open();
                while (!IsValidString(Imie.Text))
                {
                    MessageBox.Show("Zły format imienia!", "Błąd!");
                    valid = false;
                    break;
                }
                command.Parameters.AddWithValue("@Imie", Imie.Text.First().ToString().ToUpper() + Imie.Text.Substring(1));
                while (!IsValidSurname(Nazwisko.Text))
                {
                    MessageBox.Show("Zły format nazwiska!", "Błąd!");
                    valid = false;
                    break;
                }
                command.Parameters.AddWithValue("@Nazwisko",
                    Nazwisko.Text.First().ToString().ToUpper() + Nazwisko.Text.Substring(1));
                while (!IsValidPhoneNumber(Telefon.Text))
                {
                    MessageBox.Show("Zły numer telefonu!", "Błąd!");
                    valid = false;
                    break;
                }
                command.Parameters.AddWithValue("@Telefon", Telefon.Text);
                while (!IsValidEmail(Email.Text))
                {
                    MessageBox.Show("Zły adres e-mail!", "Błąd!");
                    valid = false;
                    break;
                }
                command.Parameters.AddWithValue("@Email", Email.Text);
                var date = Data_ur.Text;
                while (!IsValidDate(Data_ur.Text))
                {
                    MessageBox.Show("Zły format daty! Oczekiwano: yyyy-mm-dd", "Błąd!");
                    valid = false;
                    break;
                }
                while (!IsValidString(Miasto.Text))
                {
                    MessageBox.Show("Zły format miasta!", "Błąd!");
                    valid = false;
                    break;
                }
                command.Parameters.AddWithValue("@Miasto_ur", Miasto.Text);
                if (valid)
                {
                    var datetime = DateTime.ParseExact(date, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                    command.Parameters.AddWithValue("@Data_ur", date);
                    command.ExecuteScalar();
                }
            }
            UpdateAll();
        }

        private void PacjentAddBtn_Click(object sender, EventArgs e)
        {
            var query = "INSERT INTO Pacjent VALUES(@Imie, @Nazwisko, @Telefon, @Email, @Data_ur, @Miasto_ur)";
            using (connection = new SqlConnection(connectionString))
            using (var command = new SqlCommand(query, connection))
            {
                var valid = true;
                connection.Open();
                while (!IsValidString(Imie.Text))
                {
                    MessageBox.Show("Zły format imienia!", "Błąd!");
                    valid = false;
                    break;
                }
                command.Parameters.AddWithValue("@Imie", Imie.Text.First().ToString().ToUpper() + Imie.Text.Substring(1));
                while (!IsValidSurname(Nazwisko.Text))
                {
                    MessageBox.Show("Zły format nazwiska!", "Błąd!");
                    valid = false;
                    break;
                }
                command.Parameters.AddWithValue("@Nazwisko",
                    Nazwisko.Text.First().ToString().ToUpper() + Nazwisko.Text.Substring(1));
                while (!IsValidPhoneNumber(Telefon.Text))
                {
                    MessageBox.Show("Zły numer telefonu!", "Błąd!");
                    valid = false;
                    break;
                }
                command.Parameters.AddWithValue("@Telefon", Telefon.Text);
                while (!IsValidEmail(Email.Text))
                {
                    MessageBox.Show("Zły adres e-mail!", "Błąd!");
                    valid = false;
                    break;
                }
                command.Parameters.AddWithValue("@Email", Email.Text);
                var date = Data_ur.Text;
                while (!IsValidDate(Data_ur.Text))
                {
                    MessageBox.Show("Zły format daty! Oczekiwano: yyyy-mm-dd", "Błąd!");
                    valid = false;
                    break;
                }
                while (!IsValidString(Miasto.Text))
                {
                    MessageBox.Show("Zły format miasta!", "Błąd!");
                    valid = false;
                    break;
                }
                command.Parameters.AddWithValue("@Miasto_ur", Miasto.Text);
                if (valid)
                {
                    var datetime = DateTime.ParseExact(date, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                    command.Parameters.AddWithValue("@Data_ur", date);
                    command.ExecuteScalar();
                }
            }
            UpdateAll();
        }

        private void LekarzUpdBtn_Click(object sender, EventArgs e)
        {
            var query =
                "UPDATE Lekarz SET Imie=@Imie, Nazwisko=@Nazwisko, Telefon=@Telefon, Email=@Email, Data_ur=@Data_ur, Miejsce_ur=@Miasto_ur WHERE Id=@LekarzId";
            using (connection = new SqlConnection(connectionString))
            using (var command = new SqlCommand(query, connection))
            {
                var valid = true;
                connection.Open();
                command.Parameters.AddWithValue("@LekarzId", LekarzList.SelectedValue);
                while (!IsValidString(Imie.Text))
                {
                    MessageBox.Show("Zły format imienia!", "Błąd!");
                    valid = false;
                    break;
                }
                command.Parameters.AddWithValue("@Imie", Imie.Text.First().ToString().ToUpper() + Imie.Text.Substring(1));
                while (!IsValidSurname(Nazwisko.Text))
                {
                    MessageBox.Show("Zły format nazwiska!", "Błąd!");
                    valid = false;
                    break;
                }
                command.Parameters.AddWithValue("@Nazwisko",
                    Nazwisko.Text.First().ToString().ToUpper() + Nazwisko.Text.Substring(1));
                while (!IsValidPhoneNumber(Telefon.Text))
                {
                    MessageBox.Show("Zły numer telefonu!", "Błąd!");
                    valid = false;
                    break;
                }
                command.Parameters.AddWithValue("@Telefon", Telefon.Text);
                while (!IsValidEmail(Email.Text))
                {
                    MessageBox.Show("Zły adres e-mail!", "Błąd!");
                    valid = false;
                    break;
                }
                command.Parameters.AddWithValue("@Email", Email.Text);
                var date = Data_ur.Text;
                while (!IsValidDate(Data_ur.Text))
                {
                    MessageBox.Show("Zły format daty! Oczekiwano: yyyy-mm-dd", "Błąd!");
                    valid = false;
                    break;
                }
                while (!IsValidString(Miasto.Text))
                {
                    MessageBox.Show("Zły format miasta!", "Błąd!");
                    valid = false;
                    break;
                }
                command.Parameters.AddWithValue("@Miasto_ur", Miasto.Text);
                if (valid)
                {
                    var datetime = DateTime.ParseExact(date, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                    command.Parameters.AddWithValue("@Data_ur", date);
                    command.ExecuteScalar();
                }
            }
            UpdateAll();
        }

        private void PacjentUpdBtn_Click(object sender, EventArgs e)
        {
            var query =
                "UPDATE Pacjent SET Imie=@Imie, Nazwisko=@Nazwisko, Telefon=@Telefon, Email=@Email, Data_ur=@Data_ur, Miasto_ur=@Miasto_ur WHERE Id=@PacjentId";
            using (connection = new SqlConnection(connectionString))
            using (var command = new SqlCommand(query, connection))
            {
                var valid = true;
                connection.Open();
                command.Parameters.AddWithValue("@PacjentId", PacjentList.SelectedValue);
                while (!IsValidString(Imie.Text))
                {
                    MessageBox.Show("Zły format imienia!", "Błąd!");
                    valid = false;
                    break;
                }
                command.Parameters.AddWithValue("@Imie", Imie.Text.First().ToString().ToUpper() + Imie.Text.Substring(1));
                while (!IsValidSurname(Nazwisko.Text))
                {
                    MessageBox.Show("Zły format nazwiska!", "Błąd!");
                    valid = false;
                    break;
                }
                command.Parameters.AddWithValue("@Nazwisko",
                    Nazwisko.Text.First().ToString().ToUpper() + Nazwisko.Text.Substring(1));
                while (!IsValidPhoneNumber(Telefon.Text))
                {
                    MessageBox.Show("Zły numer telefonu!", "Błąd!");
                    valid = false;
                    break;
                }
                command.Parameters.AddWithValue("@Telefon", Telefon.Text);
                while (!IsValidEmail(Email.Text))
                {
                    MessageBox.Show("Zły adres e-mail!", "Błąd!");
                    valid = false;
                    break;
                }
                command.Parameters.AddWithValue("@Email", Email.Text);
                var date = Data_ur.Text;
                while (!IsValidDate(Data_ur.Text))
                {
                    MessageBox.Show("Zły format daty! Oczekiwano: yyyy-mm-dd", "Błąd!");
                    valid = false;
                    break;
                }
                while (!IsValidString(Miasto.Text))
                {
                    MessageBox.Show("Zły format miasta!", "Błąd!");
                    valid = false;
                    break;
                }
                command.Parameters.AddWithValue("@Miasto_ur", Miasto.Text);
                if (valid)
                {
                    var datetime = DateTime.ParseExact(date, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                    command.Parameters.AddWithValue("@Data_ur", date);
                    command.ExecuteScalar();
                }
            }
            UpdateAll();
        }

        private void LekarzDelBtn_Click(object sender, EventArgs e)
        {
            var query = "DELETE FROM Lekarz WHERE Id=@LekarzId";
            using (connection = new SqlConnection(connectionString))
            using (var command = new SqlCommand(query, connection))
            {
                connection.Open();
                command.Parameters.AddWithValue("@LekarzId", LekarzList.SelectedValue);
                var result = MessageBox.Show("Czy na pewno chcesz usunąć danego lekarza?", "Usunąć?",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (result == DialogResult.Yes)
                {
                    MessageBox.Show("Usunięto", "Usunąć?");
                    command.ExecuteScalar();
                }
            }
            UpdateAll();
        }

        private void PacjentDelBtn_Click(object sender, EventArgs e)
        {
            var query = "DELETE FROM Pacjent WHERE Id=@PacjentId";
            using (connection = new SqlConnection(connectionString))
            using (var command = new SqlCommand(query, connection))
            {
                connection.Open();
                command.Parameters.AddWithValue("@PacjentId", PacjentList.SelectedValue);
                var result = MessageBox.Show("Czy na pewno chcesz usunąć danego pacjenta?", "Usunąć?",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (result == DialogResult.Yes)
                {
                    MessageBox.Show("Usunięto", "Usunąć?");
                    command.ExecuteScalar();
                }
            }
            UpdateAll();
        }

        private void LekarzShowBtn_Click(object sender, EventArgs e)
        {
            var query = "SELECT Id, Imie, Nazwisko, Telefon, Email, Data_ur, Miejsce_ur FROM Lekarz WHERE Id=" +
                        LekarzList.SelectedValue;
            using (connection = new SqlConnection(connectionString))
            using (var command = new SqlCommand(query, connection))
            {
                connection.Open();
                command.CommandType = CommandType.Text;
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var date = reader.GetDateTime(5).ToString("yyyy-MM-dd");
                        MessageBox.Show($"Imie = {reader.GetString(1)}\n" +
                                        $"Nazwisko = {reader.GetString(2)}\n" +
                                        $"Telefon = {reader.GetString(3)}\n" +
                                        $"E-mail = {reader.GetString(4)}\n" +
                                        $"Data urodzenia = {date}\n" +
                                        $"Miejsce urodzenia = {reader.GetString(6)}\n",
                            "Lekarz");
                    }
                }
            }
        }

        private void PacjentShowBtn_Click(object sender, EventArgs e)
        {
            var query = "SELECT Id, Imie, Nazwisko, Telefon, Email, Data_ur, Miasto_ur FROM Pacjent WHERE Id=" +
                        PacjentList.SelectedValue;
            using (connection = new SqlConnection(connectionString))
            using (var command = new SqlCommand(query, connection))
            {
                connection.Open();
                command.CommandType = CommandType.Text;
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var date = reader.GetDateTime(5).ToString("yyyy-MM-dd");
                        MessageBox.Show($"Imie = {reader.GetString(1)}\n" +
                                        $"Nazwisko = {reader.GetString(2)}\n" +
                                        $"Telefon = {reader.GetString(3)}\n" +
                                        $"E-mail = {reader.GetString(4)}\n" +
                                        $"Data urodzenia = {date}\n" +
                                        $"Miejsce urodzenia = {reader.GetString(6)}\n",
                            "Pacjent");
                    }
                }
            }
        }

        private void UpdateChoroby()
        {
            var query = "SELECT Id, Nazwa, Opis, Pochodzenie, Nr_medyczny, Czy_szczepienie FROM Choroba";
            using (connection = new SqlConnection(connectionString))
            using (var adapter = new SqlDataAdapter(query, connection))
            {
                var chorobaTable = new DataTable();
                adapter.Fill(chorobaTable);
                ChorobaList.DisplayMember = "Nazwa";
                ChorobaList.ValueMember = "Id";
                ChorobaList.DataSource = chorobaTable;
                HistoriaChorobaList.DisplayMember = "Nazwa";
                HistoriaChorobaList.ValueMember = "Id";
                HistoriaChorobaList.DataSource = chorobaTable;
            }
        }

        private void ChorobaList_SelectedIndexChanged(object sender, EventArgs e)
        {
            var query = "SELECT Id, Nazwa, Opis, Pochodzenie, Nr_medyczny, Czy_szczepienie FROM Choroba WHERE Id =" +
                        ChorobaList.SelectedValue;
            using (connection = new SqlConnection(connectionString))
            using (var command = new SqlCommand(query, connection))
            {
                connection.Open();
                command.CommandType = CommandType.Text;
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        ChorobaNazwa.Text = (reader.GetString(1));
                        ChorobaOpis.Text = (reader.GetString(2));
                        ChorobaPochodzenie.Text = (reader.GetString(3));
                        ChorobaNr_medyczny.Text = (reader.GetDouble(4).ToString());
                        ChorobaCzy_szczepienie.Text = (reader.GetBoolean(5).ToString());
                    }
                }
            }
        }

        private void ChorobaAddBtn_Click(object sender, EventArgs e)
        {
            var query = "INSERT INTO Choroba VALUES(@Nazwa, @Opis, @Pochodzenie, @Nr_medyczny, @Czy_szczepienie)";
            using (connection = new SqlConnection(connectionString))
            using (var command = new SqlCommand(query, connection))
            {
                var valid = true;
                connection.Open();
                while (!IsValidString(ChorobaNazwa.Text))
                {
                    MessageBox.Show("Zły format nazwy!", "Błąd!");
                    valid = false;
                    break;
                }
                command.Parameters.AddWithValue("@Nazwa",
                    ChorobaNazwa.Text.First().ToString().ToUpper() + ChorobaNazwa.Text.Substring(1));
                while (!IsValidString(ChorobaOpis.Text))
                {
                    MessageBox.Show("Zły format opisu!", "Błąd!");
                    valid = false;
                    break;
                }
                command.Parameters.AddWithValue("@Opis",
                    ChorobaOpis.Text.First().ToString().ToUpper() + ChorobaOpis.Text.Substring(1));
                while (!IsValidString(ChorobaPochodzenie.Text))
                {
                    MessageBox.Show("Zły format opisu pochodzenia!", "Błąd!");
                    valid = false;
                    break;
                }
                command.Parameters.AddWithValue("@Pochodzenie",
                    ChorobaPochodzenie.Text.First().ToString().ToUpper() + ChorobaPochodzenie.Text.Substring(1));
                var value = ChorobaNr_medyczny.Text;
                while (!IsValidDouble(value))
                {
                    MessageBox.Show("Zły format nr medycznego!", "Błąd!");
                    valid = false;
                    break;
                }
                while (!IsValidBool(ChorobaCzy_szczepienie.Text))
                {
                    MessageBox.Show("Zły format odpowiedzi na szczepionkę!", "Błąd!");
                    valid = false;
                    break;
                }
                command.Parameters.AddWithValue("@Czy_szczepienie", ChorobaCzy_szczepienie.Text);
                if (valid)
                {
                    var result = Convert.ToDouble(value);
                    command.Parameters.AddWithValue("@Nr_medyczny", result);
                    command.ExecuteScalar();
                }
            }
            UpdateAll();
        }

        private void ChorobaUpdBtn_Click(object sender, EventArgs e)
        {
            var query =
                "UPDATE Choroba SET Nazwa=@Nazwa, Opis=@Opis, Pochodzenie=@Pochodzenie, Nr_medyczny=@Nr_medyczny, Czy_szczepienie=@Czy_szczepienie WHERE Id=@ChorobaId";
            using (connection = new SqlConnection(connectionString))
            using (var command = new SqlCommand(query, connection))
            {
                var valid = true;
                connection.Open();
                command.Parameters.AddWithValue("@ChorobaId", ChorobaList.SelectedValue);
                while (!IsValidString(ChorobaNazwa.Text))
                {
                    MessageBox.Show("Zły format nazwy!", "Błąd!");
                    valid = false;
                    break;
                }
                command.Parameters.AddWithValue("@Nazwa",
                    ChorobaNazwa.Text.First().ToString().ToUpper() + ChorobaNazwa.Text.Substring(1));
                while (!IsValidString(ChorobaOpis.Text))
                {
                    MessageBox.Show("Zły format opisu!", "Błąd!");
                    valid = false;
                    break;
                }
                command.Parameters.AddWithValue("@Opis",
                    ChorobaOpis.Text.First().ToString().ToUpper() + ChorobaOpis.Text.Substring(1));
                while (!IsValidString(ChorobaPochodzenie.Text))
                {
                    MessageBox.Show("Zły format opisu pochodzenia!", "Błąd!");
                    valid = false;
                    break;
                }
                var value = ChorobaNr_medyczny.Text;
                while (!IsValidDouble(value))
                {
                    MessageBox.Show("Zły format nr medycznego!", "Błąd!");
                    valid = false;
                    break;
                }
                while (!IsValidBool(ChorobaCzy_szczepienie.Text))
                {
                    MessageBox.Show("Zły format odpowiedzi na szczepionkę!", "Błąd!");
                    valid = false;
                    break;
                }
                command.Parameters.AddWithValue("@Czy_szczepienie", ChorobaCzy_szczepienie.Text);
                if (valid)
                {
                    var result = Convert.ToDouble(value);
                    command.Parameters.AddWithValue("@Nr_medyczny", result);
                    command.ExecuteScalar();
                }
            }
            UpdateAll();
        }

        private void ChorobaDelBtn_Click(object sender, EventArgs e)
        {
            var query = "DELETE FROM Choroba WHERE Id=@ChorobaId";
            using (connection = new SqlConnection(connectionString))
            using (var command = new SqlCommand(query, connection))
            {
                connection.Open();
                command.Parameters.AddWithValue("@ChorobaId", ChorobaList.SelectedValue);
                var result = MessageBox.Show("Czy na pewno chcesz usunąć daną chorobe?", "Usunąć?",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (result == DialogResult.Yes)
                {
                    MessageBox.Show("Usunięto", "Usunąć?");
                    command.ExecuteScalar();
                }
            }
            UpdateAll();
        }

        private void ChorobaShowBtn_Click(object sender, EventArgs e)
        {
            var query = "SELECT Id, Nazwa, Opis, Pochodzenie, Nr_medyczny, Czy_szczepienie FROM Choroba WHERE Id =" +
                        ChorobaList.SelectedValue;
            using (connection = new SqlConnection(connectionString))
            using (var command = new SqlCommand(query, connection))
            {
                connection.Open();
                command.CommandType = CommandType.Text;
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        MessageBox.Show($"Nazwa = {reader.GetString(1)}\n" +
                                        $"Opis = {reader.GetString(2)}\n" +
                                        $"Pochodzenie = {reader.GetString(3)}\n" +
                                        $"Nr medyczny = {reader.GetDouble(4)}\n" +
                                        $"Szczepionka = {reader.GetBoolean(5)}",
                            "Choroba");
                    }
                }
            }
        }

        private void UpdateWizyty()
        {
            var query =
                "SELECT Id, CAST(CAST(Data_wizyty AS date) AS varchar) + ' - ' + (SELECT (Nazwisko + ' ' + Imie) AS Pac FROM Pacjent WHERE Id = PacjentId) AS Show FROM Wizyta";
            using (connection = new SqlConnection(connectionString))
            using (var adapter = new SqlDataAdapter(query, connection))
            {
                var wizytaTable = new DataTable();
                adapter.Fill(wizytaTable);
                WizytaList.DisplayMember = "Show";
                WizytaList.ValueMember = "Id";
                WizytaList.DataSource = wizytaTable;
                HistoriaWizytaList.DisplayMember = "Show";
                HistoriaWizytaList.ValueMember = "Id";
                HistoriaWizytaList.DataSource = wizytaTable;
            }
        }

        private void WizytaList_SelectedIndexChanged(object sender, EventArgs e)
        {
            var query =
                "SELECT Id, LekarzId, (SELECT (Nazwisko + ' ' + Imie) AS Lek FROM Lekarz WHERE Id = LekarzId) AS Lekarz, PacjentId, (SELECT (Nazwisko + ' ' + Imie) AS Pac FROM Pacjent WHERE Id = PacjentId) AS Pacjent, Data_wizyty, Zalecenia, Oplata FROM Wizyta WHERE Id =" +
                WizytaList.SelectedValue;
            using (connection = new SqlConnection(connectionString))
            using (var command = new SqlCommand(query, connection))
            {
                connection.Open();
                command.CommandType = CommandType.Text;
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        WizytaLekarzList.SelectedValue = (reader.GetInt32(1));
                        WizytaPacjentList.SelectedValue = (reader.GetInt32(3));
                        var date = reader.GetDateTime(5).ToString("yyyy-MM-dd");
                        WizytaData_wizyty.Text = date;
                        WizytaZalecenia.Text = (reader.GetString(6));
                        WizytaOplata.Text = (reader.GetSqlMoney(7).ToString());
                    }
                }
            }
        }

        private void WizytaAddBtn_Click(object sender, EventArgs e)
        {
            var query = "INSERT INTO Wizyta VALUES(@Lekarz, @Pacjent, @Data_wizyty, @Zalecenia, @Oplata)";
            using (connection = new SqlConnection(connectionString))
            using (var command = new SqlCommand(query, connection))
            {
                var valid = true;
                connection.Open();
                command.Parameters.AddWithValue("@Lekarz", WizytaLekarzList.SelectedValue);
                command.Parameters.AddWithValue("@Pacjent", WizytaPacjentList.SelectedValue);
                var date = WizytaData_wizyty.Text;
                while (!IsValidDate(date))
                {
                    MessageBox.Show("Zły format daty! Oczekiwano: yyyy-mm-dd", "Błąd!");
                    valid = false;
                    break;
                }
                while (!IsValidLetter(WizytaZalecenia.Text))
                {
                    MessageBox.Show("Zły format opisu zaleceń!", "Błąd!");
                    valid = false;
                    break;
                }
                command.Parameters.AddWithValue("@Zalecenia",
                    WizytaZalecenia.Text.First().ToString().ToUpper() + WizytaZalecenia.Text.Substring(1));
                var money = WizytaOplata.Text;
                while (!IsValidMoney(money))
                {
                    MessageBox.Show("Zły format opłaty!", "Błąd!");
                    valid = false;
                    break;
                }
                if (valid)
                {
                    var datetime = DateTime.ParseExact(date, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                    command.Parameters.AddWithValue("@Data_wizyty", date);
                    var price = SqlMoney.Parse(money);
                    command.Parameters.AddWithValue("@Oplata", money);
                    command.ExecuteScalar();
                }
            }
            UpdateAll();
        }

        private void WizytaUpdBtn_Click(object sender, EventArgs e)
        {
            var query =
                "UPDATE Wizyta SET LekarzId=@Lekarz, PacjentId=@Pacjent, Data_wizyty=@Data_wizyty, Zalecenia=@Zalecenia, Oplata=@Oplata WHERE Id=@WizytaId";
            using (connection = new SqlConnection(connectionString))
            using (var command = new SqlCommand(query, connection))
            {
                var valid = true;
                connection.Open();
                command.Parameters.AddWithValue("@WizytaId", WizytaList.SelectedValue);
                command.Parameters.AddWithValue("@Lekarz", WizytaLekarzList.SelectedValue);
                command.Parameters.AddWithValue("@Pacjent", WizytaPacjentList.SelectedValue);
                var date = WizytaData_wizyty.Text;
                while (!IsValidDate(date))
                {
                    MessageBox.Show("Zły format daty! Oczekiwano: yyyy-mm-dd", "Błąd!");
                    valid = false;
                    break;
                }
                while (!IsValidLetter(WizytaZalecenia.Text))
                {
                    MessageBox.Show("Zły format opisu zaleceń!", "Błąd!");
                    valid = false;
                    break;
                }
                command.Parameters.AddWithValue("@Zalecenia",
                    WizytaZalecenia.Text.First().ToString().ToUpper() + WizytaZalecenia.Text.Substring(1));
                var money = WizytaOplata.Text;
                while (!IsValidMoney(money))
                {
                    MessageBox.Show("Zły format opłaty!", "Błąd!");
                    valid = false;
                    break;
                }
                if (valid)
                {
                    var datetime = DateTime.ParseExact(date, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                    command.Parameters.AddWithValue("@Data_wizyty", date);
                    var price = SqlMoney.Parse(money);
                    command.Parameters.AddWithValue("@Oplata", money);
                    command.ExecuteScalar();
                }
            }
            UpdateAll();
        }

        private void WizytaDelBtn_Click(object sender, EventArgs e)
        {
            var query = "DELETE FROM Wizyta WHERE Id=@WizytaId";
            using (connection = new SqlConnection(connectionString))
            using (var command = new SqlCommand(query, connection))
            {
                connection.Open();
                command.Parameters.AddWithValue("@WizytaId", WizytaList.SelectedValue);
                var result = MessageBox.Show("Czy na pewno chcesz usunąć dany wpis o wizycie?", "Usunąć?",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (result == DialogResult.Yes)
                {
                    MessageBox.Show("Usunięto", "Usunąć?");
                    command.ExecuteScalar();
                }
            }
            UpdateAll();
        }

        private void WizytaShowBtn_Click(object sender, EventArgs e)
        {
            var query =
                "SELECT Id, LekarzId, (SELECT (Nazwisko + ' ' + Imie) AS Lek FROM Lekarz WHERE Id = LekarzId) AS Lekarz, PacjentId, (SELECT (Nazwisko + ' ' + Imie) AS Pac FROM Pacjent WHERE Id = PacjentId) AS Pacjent, Data_wizyty, Zalecenia, Oplata FROM Wizyta WHERE Id =" +
                WizytaList.SelectedValue;
            using (connection = new SqlConnection(connectionString))
            using (var command = new SqlCommand(query, connection))
            {
                connection.Open();
                command.CommandType = CommandType.Text;
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var date = reader.GetDateTime(5).ToString("yyyy-MM-dd");
                        var money = WizytaOplata.Text;
                        MessageBox.Show($"Pacjent = {reader.GetString(4)}\n" +
                                        $"Lekarz = {reader.GetString(2)}\n" +
                                        $"Data wizyty = {date}\n" +
                                        $"Zalecenia = {reader.GetString(6)}\n" +
                                        $"Oplata = {money}",
                            "Dane o wizycie");
                    }
                }
            }
        }

        private void UpdateHistoria()
        {
            var query =
                "SELECT ((SELECT CAST(CAST(Data_wizyty AS date) AS varchar) + ' - ' + (SELECT (Nazwisko + ' ' + Imie) AS Pac FROM Pacjent WHERE Id = PacjentId) AS Wiz FROM Wizyta WHERE Id = WizytaId) + ' -> ' + (SELECT Nazwa FROM Choroba WHERE Id = ChorobaId)) AS Show FROM Historia_chorob";
            using (connection = new SqlConnection(connectionString))
            using (var adapter = new SqlDataAdapter(query, connection))
            {
                var historiaTable = new DataTable();
                adapter.Fill(historiaTable);
                HistoriaList.DisplayMember = "Show";
                HistoriaList.DataSource = historiaTable;
            }
        }

        private void HistoriaList_SelectedIndexChanged(object sender, EventArgs e)
        {
            var query =
                "SELECT WizytaId, ChorobaId, ((SELECT CAST(CAST(Data_wizyty AS date) AS varchar) + ' - ' + (SELECT (Nazwisko + ' ' + Imie) AS Pac FROM Pacjent WHERE Id = PacjentId) AS Wiz FROM Wizyta WHERE Id = WizytaId) + ' -> ' + (SELECT Nazwa FROM Choroba WHERE Id = ChorobaId)) AS Show FROM Historia_chorob WHERE WizytaId=@Wizyta";
            using (connection = new SqlConnection(connectionString))
            using (var command = new SqlCommand(query, connection))
            {
                connection.Open();
                command.Parameters.AddWithValue("@Wizyta", (HistoriaList.SelectedIndex + 1));
                command.CommandType = CommandType.Text;
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        HistoriaWizytaList.SelectedValue = (reader.GetInt32(0));
                        HistoriaChorobaList.SelectedValue = (reader.GetInt32(1));
                    }
                }
            }
        }

        private void HistoriaAddBtn_Click(object sender, EventArgs e)
        {
            var query = "INSERT INTO Historia_chorob VALUES(@Wizyta, @Choroba)";
            using (connection = new SqlConnection(connectionString))
            using (var command = new SqlCommand(query, connection))
            {
                connection.Open();
                command.Parameters.AddWithValue("@Wizyta", HistoriaWizytaList.SelectedValue);
                command.Parameters.AddWithValue("@Choroba", HistoriaChorobaList.SelectedValue);
                command.ExecuteScalar();
            }
            UpdateAll();
        }

        private void HistoriaUpdBtn_Click(object sender, EventArgs e)
        {
            var query = "UPDATE Historia_chorob SET ChorobaId=@Choroba WHERE WizytaId=@Wizyta";
            using (connection = new SqlConnection(connectionString))
            using (var command = new SqlCommand(query, connection))
            {
                connection.Open();
                command.Parameters.AddWithValue("@Choroba", HistoriaChorobaList.SelectedValue);
                command.Parameters.AddWithValue("@Wizyta", HistoriaWizytaList.SelectedValue);
                command.ExecuteScalar();
            }
            UpdateAll();
        }

        private void HistoriaDelBtn_Click(object sender, EventArgs e)
        {
            var query = "DELETE FROM Historia_chorob WHERE WizytaId=@Wizyta";
            using (connection = new SqlConnection(connectionString))
            using (var command = new SqlCommand(query, connection))
            {
                connection.Open();
                command.Parameters.AddWithValue("@Wizyta", HistoriaWizytaList.SelectedValue);
                var result = MessageBox.Show("Czy na pewno chcesz usunąć dany wpis z historii?", "Usunąć?",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (result == DialogResult.Yes)
                {
                    MessageBox.Show("Usunięto", "Usunąć?");
                    command.ExecuteScalar();
                }
            }
            UpdateAll();
        }

        private void HistoriaShowBtn_Click(object sender, EventArgs e)
        {
            var query =
                "SELECT WizytaId, ChorobaId, (SELECT CAST(CAST(Data_wizyty AS date) AS varchar) FROM Wizyta WHERE Id = WizytaId) AS Data, (SELECT (SELECT (Nazwisko + ' ' + Imie) AS Pac FROM Pacjent WHERE Id = PacjentId) AS Wiz FROM Wizyta WHERE Id = WizytaId) AS Pacjent, (SELECT Nazwa FROM Choroba WHERE Id = ChorobaId) AS Choroba FROM Historia_chorob WHERE WizytaId=@Wizyta";
            using (connection = new SqlConnection(connectionString))
            using (var command = new SqlCommand(query, connection))
            {
                connection.Open();
                command.Parameters.AddWithValue("@Wizyta", (HistoriaList.SelectedIndex + 1));
                command.CommandType = CommandType.Text;
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        MessageBox.Show($"Pacjent = {reader.GetString(3)}\n" +
                                        $"Choroba = {reader.GetString(4)}\n" +
                                        $"Data wizyty = {reader.GetString(2)}",
                            "Dane o wizycie w historii");
                    }
                }
            }
        }
    }
}