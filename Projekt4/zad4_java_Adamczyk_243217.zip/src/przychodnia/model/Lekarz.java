package przychodnia.model;

import javafx.beans.property.SimpleStringProperty;

public class Lekarz {
    private final SimpleStringProperty id;
    private final SimpleStringProperty imie;
    private final SimpleStringProperty nazwisko;
    private final SimpleStringProperty telefon;
    private final SimpleStringProperty email;
    private final SimpleStringProperty data_ur;
    private final SimpleStringProperty miasto_ur;

    public Lekarz(String id, String imie, String nazwisko, String telefon, String email, String data_ur, String miasto_ur) {
        this.id = new SimpleStringProperty(id);
        this.imie = new SimpleStringProperty(imie);
        this.nazwisko = new SimpleStringProperty(nazwisko);
        this.telefon = new SimpleStringProperty(telefon);
        this.email = new SimpleStringProperty(email);
        this.data_ur = new SimpleStringProperty(data_ur);
        this.miasto_ur = new SimpleStringProperty(miasto_ur);
    }

    public String getId() {
        return id.get();
    }

    public void setId(String id) {
        this.id.set(id);
    }

    public SimpleStringProperty idProperty() {
        return this.id;
    }

    public String getImie() {
        return imie.get();
    }

    public void setImie(String imie) {
        this.imie.set(imie);
    }

    public SimpleStringProperty imieProperty() {
        return imie;
    }

    public String getNazwisko() {
        return nazwisko.get();
    }

    public void setNazwisko(String nazwisko) {
        this.nazwisko.set(nazwisko);
    }

    public SimpleStringProperty nazwiskoProperty() {
        return nazwisko;
    }

    public String getTelefon() {
        return telefon.get();
    }

    public void setTelefon(String telefon) {
        this.telefon.set(telefon);
    }

    public SimpleStringProperty telefonProperty() {
        return telefon;
    }

    public String getEmail() {
        return email.get();
    }

    public void setEmail(String email) {
        this.email.set(email);
    }

    public SimpleStringProperty emailProperty() {
        return email;
    }

    public String getData_ur() {
        return data_ur.get();
    }

    public void setData_ur(String data_ur) {
        this.data_ur.set(data_ur);
    }

    public SimpleStringProperty data_urProperty() {
        return data_ur;
    }

    public String getMiasto_ur() {
        return miasto_ur.get();
    }

    public void setMiasto_ur(String miasto_ur) {
        this.miasto_ur.set(miasto_ur);
    }

    public SimpleStringProperty miasto_urProperty() {
        return miasto_ur;
    }
}
