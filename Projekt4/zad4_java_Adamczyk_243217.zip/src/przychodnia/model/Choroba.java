package przychodnia.model;

import javafx.beans.property.SimpleStringProperty;

public class Choroba {
    private final SimpleStringProperty id;
    private final SimpleStringProperty nazwa;
    private final SimpleStringProperty opis;
    private final SimpleStringProperty pochodzenie;
    private final SimpleStringProperty nr_medyczny;
    private final SimpleStringProperty ilosc_mozliwych_szczepien;

    public Choroba(String id, String nazwa, String opis, String pochodzenie, String nr_medyczny, String ilosc_mozliwych_szczepien) {
        this.id = new SimpleStringProperty(id);
        this.nazwa = new SimpleStringProperty(nazwa);
        this.opis = new SimpleStringProperty(opis);
        this.pochodzenie = new SimpleStringProperty(pochodzenie);
        this.nr_medyczny = new SimpleStringProperty(nr_medyczny);
        this.ilosc_mozliwych_szczepien = new SimpleStringProperty(ilosc_mozliwych_szczepien);
    }

    public String getId() {
        return id.get();
    }

    public void setId(String id) {
        this.id.set(id);
    }

    public SimpleStringProperty idProperty() {
        return this.id;
    }

    public String getNazwa() {
        return nazwa.get();
    }

    public void setNazwa(String nazwa) {
        this.nazwa.set(nazwa);
    }

    public SimpleStringProperty nazwaProperty() {
        return nazwa;
    }

    public String getOpis() {
        return opis.get();
    }

    public void setOpis(String opis) {
        this.opis.set(opis);
    }

    public SimpleStringProperty opisProperty() {
        return opis;
    }

    public String getPochodzenie() {
        return pochodzenie.get();
    }

    public void setPochodzenie(String pochodzenie) {
        this.pochodzenie.set(pochodzenie);
    }

    public SimpleStringProperty pochodzenieProperty() {
        return pochodzenie;
    }

    public String getNr_medyczny() {
        return nr_medyczny.get();
    }

    public void setNr_medyczny(String nr_medyczny) {
        this.nr_medyczny.set(nr_medyczny);
    }

    public SimpleStringProperty nr_medycznyProperty() {
        return nr_medyczny;
    }

    public String getIlosc_mozliwych_szczepien() {
        return ilosc_mozliwych_szczepien.get();
    }

    public void setIlosc_mozliwych_szczepien(String ilosc_mozliwych_szczepien) {
        this.ilosc_mozliwych_szczepien.set(ilosc_mozliwych_szczepien);
    }

    public SimpleStringProperty ilosc_mozliwych_szczepienProperty() {
        return ilosc_mozliwych_szczepien;
    }
}
