package login.service;

import dbconnection.DbConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginService {
    private Connection connection;

    public LoginService() throws Exception {
        this.connection = DbConnection.connect("Projekt4.sqlite",
                "base/Przychodnia_lekarska_CREATE.sql", "base/Przychodnia_lekarska_INSERT.sql");
    }

    public boolean isDatabaseConnected() {
        return this.connection != null;
    }

    public boolean checkLoginData(String login, String password) throws Exception {
        PreparedStatement preparedStatement = null;
        ResultSet result = null;
        String sql = "SELECT * FROM konto where login = ? and haslo = ?;";
        try {
            preparedStatement = this.connection.prepareStatement(sql);
            preparedStatement.setString(1, login);
            preparedStatement.setString(2, password);
            result = preparedStatement.executeQuery();
            return result.next();
        } finally {
            preparedStatement.close();
            result.close();
        }
    }

}