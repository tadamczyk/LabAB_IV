CREATE TABLE pacjent(
  id INTEGER NOT NULL IDENTITY(1,1),
  imie VARCHAR(20) NOT NULL,
  nazwisko VARCHAR(40) NOT NULL,
  telefon VARCHAR(13) NOT NULL,
  email VARCHAR(100) NOT NULL,
  data_ur DATE NOT NULL,
  miasto_ur VARCHAR(40) NOT NULL
);

CREATE TABLE lekarz(
  id INTEGER NOT NULL IDENTITY(1,1),
  imie VARCHAR(20) NOT NULL,
  nazwisko VARCHAR(40) NOT NULL,
  telefon VARCHAR(13) NOT NULL,
  email VARCHAR(100) NOT NULL,
  data_ur DATE NOT NULL,
  miasto_ur VARCHAR(40) NOT NULL
);

CREATE TABLE choroba(
  id INTEGER NOT NULL IDENTITY(1,1),
  nazwa VARCHAR(50) NOT NULL,
  opis VARCHAR(200) NOT NULL,
  pochodzenie VARCHAR(40) NOT NULL,
  nr_medyczny DOUBLE NOT NULL,
  czy_szczepienie BOOL NOT NULL
);

CREATE TABLE wizyta(
  id INTEGER NOT NULL IDENTITY(1,1),
  lekarz_id INTEGER NOT NULL REFERENCES lekarz(id),
  pacjent_id INTEGER NOT NULL REFERENCES pacjent(id),
  data_wizyty DATETIME NOT NULL,
  zalecenia VARCHAR(200) NOT NULL,
  oplata DECIMAL NOT NULL
);

CREATE TABLE historia_chorob(
  wizyta_id INTEGER NOT NULL REFERENCES wizyta(id),
  choroba_id INTEGER NOT NULL REFERENCES choroba(id),
  PRIMARY KEY(wizyta_id, choroba_id)
);
