package przychodnia.model;

import javafx.beans.property.SimpleStringProperty;

public class Historia {
    private final SimpleStringProperty wizyta_id;
    private final SimpleStringProperty choroba_id;
    private final SimpleStringProperty zalecenia;
    private final SimpleStringProperty oplata;

    public Historia(String wizyta_id, String choroba_id, String zalecenia, String oplata) {
        this.wizyta_id = new SimpleStringProperty(wizyta_id);
        this.choroba_id = new SimpleStringProperty(choroba_id);
        this.zalecenia = new SimpleStringProperty(zalecenia);
        this.oplata = new SimpleStringProperty(oplata);
    }

    public String getWizyta_id() {
        return wizyta_id.get();
    }

    public void setWizyta_id(String wizyta_id) {
        this.wizyta_id.set(wizyta_id);
    }

    public SimpleStringProperty wizyta_idProperty() {
        return wizyta_id;
    }

    public String getChoroba_id() {
        return choroba_id.get();
    }

    public void setChoroba_id(String choroba_id) {
        this.choroba_id.set(choroba_id);
    }

    public SimpleStringProperty choroba_idProperty() {
        return choroba_id;
    }

    public String getZalecenia() {
        return zalecenia.get();
    }

    public void setZalecenia(String zalecenia) {
        this.zalecenia.set(zalecenia);
    }

    public SimpleStringProperty zaleceniaProperty() {
        return zalecenia;
    }

    public String getOplata() {
        return oplata.get();
    }

    public void setOplata(String oplata) {
        this.oplata.set(oplata);
    }

    public SimpleStringProperty oplataProperty() {
        return oplata;
    }
}
