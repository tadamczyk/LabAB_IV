package przychodnia.model;

import javafx.beans.property.SimpleStringProperty;

public class Wizyta {
    private final SimpleStringProperty id;
    private final SimpleStringProperty lekarz_id;
    private final SimpleStringProperty pacjent_id;
    private final SimpleStringProperty data_wizyty;

    public Wizyta(String id, String lekarz_id, String pacjent_id, String data_wizyty) {
        this.id = new SimpleStringProperty(id);
        this.lekarz_id = new SimpleStringProperty(lekarz_id);
        this.pacjent_id = new SimpleStringProperty(pacjent_id);
        this.data_wizyty = new SimpleStringProperty(data_wizyty);
    }

    public String getId() {
        return id.get();
    }

    public void setId(String id) {
        this.id.set(id);
    }

    public SimpleStringProperty idProperty() {
        return this.id;
    }

    public String getLekarz_id() {
        return lekarz_id.get();
    }

    public void setLekarz_id(String lekarz_id) {
        this.lekarz_id.set(lekarz_id);
    }

    public SimpleStringProperty lekarz_idProperty() {
        return lekarz_id;
    }

    public String getPacjent_id() {
        return pacjent_id.get();
    }

    public void setPacjent_id(String pacjent_id) {
        this.pacjent_id.set(pacjent_id);
    }

    public SimpleStringProperty pacjent_idProperty() {
        return pacjent_id;
    }

    public String getData_wizyty() {
        return data_wizyty.get();
    }

    public void setData_wizyty(String data_wizyty) {
        this.data_wizyty.set(data_wizyty);
    }

    public SimpleStringProperty data_wizytyProperty() {
        return data_wizyty;
    }
}
